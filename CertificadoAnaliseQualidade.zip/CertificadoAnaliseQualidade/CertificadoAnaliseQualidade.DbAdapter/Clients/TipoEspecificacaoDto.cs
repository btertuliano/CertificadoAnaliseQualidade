﻿namespace CertificadoAnaliseQualidade.DbAdapter.Clients;

public class TipoEspecificacaoDto
{
    public string Z11_COD { get; set; }
    public string Z11_DESC { get; set; }
    public decimal Z12_VALOR { get; set; }
    public decimal Z12_TOLER { get; set; }
}
