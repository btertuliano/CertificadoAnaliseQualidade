﻿using CertificadoAnaliseQualidade.Domain.Models;

namespace CertificadoAnaliseQualidade.WebMvc.Models.Formulario;

public class AnaliseVisualPreTesteLeituraViewModel
{
    public AnaliseVisualItemPreTeste AnaliseVisualItemPreTeste { get; private set; }

    public AnaliseVisualPreTesteLeituraViewModel(AnaliseVisualItemPreTeste analiseVisualItemPreTeste)
    {
        AnaliseVisualItemPreTeste = analiseVisualItemPreTeste;
    }

    private string AnaliseVisualPreTesteTipo(AnaliseVisualItemPreTesteTipo analiseVisualItemPreTesteTipo)
    {
        switch (analiseVisualItemPreTesteTipo)
        {
            case AnaliseVisualItemPreTesteTipo.Sim:
                return "Sim";
            case AnaliseVisualItemPreTesteTipo.Nao:
                return "Não";
            case AnaliseVisualItemPreTesteTipo.Na:
                return "N/A";
            default:
                return "N/A";
        }
    }
    public string Granulometria => AnaliseVisualPreTesteTipo(AnaliseVisualItemPreTeste.Granulometria);
    public string Plastificacao => AnaliseVisualPreTesteTipo(AnaliseVisualItemPreTeste.Plastificacao);
    public string Cor => AnaliseVisualPreTesteTipo(AnaliseVisualItemPreTeste.Cor);
    public string MaDispercaoSilica => AnaliseVisualPreTesteTipo(AnaliseVisualItemPreTeste.MaDispersaoSilica);
    public string Olhinhos => AnaliseVisualPreTesteTipo(AnaliseVisualItemPreTeste.Olhinhos);
    public string FitaMonorosca => AnaliseVisualPreTesteTipo(AnaliseVisualItemPreTeste.FitaMonorosca);
    public string Gases => AnaliseVisualPreTesteTipo(AnaliseVisualItemPreTeste.Gases);

}
