﻿class CadastroViewModel {
    constructor(certificado, produto, preTeste) {
        this.Certificado = certificado;
        this.Produto = produto;
        this.Certificado.PreTeste = preTeste;
        this.novoItemPreTeste = null;
        this.novaAlteracaoFormula = null;
        this.novoResultado = null;
        this.novaReanalise = null;
    }

    Update() {
        $.ajax({
            url: '/Formulario/AtualizarCertificado',
            type: 'PUT', data: this.Certificado,
            success: function (result) {
            }
        });
    }

    UpdatePreTeste() {
        $.ajax({
            url: '/Formulario/AtualizarPreTeste',
            type: 'PUT', data: this.Certificado.PreTeste,
            success: function (result) {
            }
        });
    }

    CadastrarItemPreTeste(callBack) {
        $.post('/Formulario/CadastrarItemPreTeste', this.novoItemPreTeste, function (novoItem) {

            model.Certificado.PreTeste.itens.push(novoItem);

            $.post('/Formulario/ItensPreTeste', novoItem, function (partial) {
                $('#exibirItensPreTeste, #itensPreTeste').show();
                $('#itensPreTeste').append(partial);
            });

            callBack();
        });
    }

    CadastrarResultado(callBack) {
        $.post('/Formulario/CadastrarResultado', this.novoResultado, function (novoResultado) {

            model.Certificado.resultadosCertificado.push(novoResultado);

            $.post('/Formulario/ResultadoCertificado', novoResultado, function (partial) {
                $('#exibirResultado, #resultadoCertificado').show();
                $('#resultadoCertificado').append(partial);
            });

            callBack();
        });
    }

    CadastrarAlteracaoFormula(callBack) {
        $.post('/Formulario/CadastrarAlteracaoFormula', this.novaAlteracaoFormula, function (novaAlteracaoFormula) {

            $.get('/Formulario/AlteracoesFormulas', novaAlteracaoFormula, function (partial) {
                $('#exibirAlteracoesFormulas, #alteracaoFormulaCertificado').show();
                $('#alteracaoFormulaCertificado').append(partial);
            });

            callBack();
        });
    }

    CadastrarReanaliseResultado(callBack) {
        $.post('/Formulario/CadastrarReanaliseResultado', this.novaReanalise, function (novaReanalise) {

            $.get('/Formulario/ReanaliseResultado', novaReanalise, function (partial) {
                $('#exibirResultado, #resultadoCertificado').show();
                $('#resultadoCertificado').append(partial);
            });

            callBack();
        });
    }

    ObterAlteracaoFormula(callBack) {
        $.post('/Formulario/ObterAlteracoesFormulasAsync', this.novoResultado, function (novoResultado) {

            $.get('/Formulario/Resultado', novoResultado, function (partial) {
                $('#resultadoCertificado').append(partial);
            });

            callBack();
        });
    }

}

class ItemPreTeste {
    constructor(novoItem) {
        this.Codigo = novoItem.Codigo;
        this.PreTesteCodigo = novoItem.PreTesteCodigo;
        this.DataHoraInjecao = novoItem.DataHoraInjecao;
        this.HoraTeste = novoItem.HoraTeste;
        this.HoraRetorno = novoItem.HoraRetorno;
        this.AssinaturaAnalista = novoItem.AssinaturaAnalista;
        this.AssinaturaMonitorLider = novoItem.AssinaturaMonitorLider;
        this.Observacao = novoItem.Observacao;
        this.AnaliseVisualItemPreTeste = novoItem.AnaliseVisualItemPreTeste;
        this.TiposEspecificacoes = novoItem.TiposEspecificacoes;
        this.Abrasao = novoItem.Abrasao;
    }
}

class AnaliseVisualItemPreTeste {
    constructor(novaAnaliseVisualItemPreTeste) {
        this.Codigo = novaAnaliseVisualItemPreTeste.Codigo;
        this.ItemPreTesteCodigo = novaAnaliseVisualItemPreTeste.ItemPreTesteCodigo;
        this.Granulometria = novaAnaliseVisualItemPreTeste.Granulometria;
        this.Plastificacao = novaAnaliseVisualItemPreTeste.Plastificacao;
        this.Cor = novaAnaliseVisualItemPreTeste.Cor;
        this.MaDispersaoSilica = novaAnaliseVisualItemPreTeste.MaDispersaoSilica;
        this.FitaMonorosca = novaAnaliseVisualItemPreTeste.FitaMonorosca;
        this.Gases = novaAnaliseVisualItemPreTeste.Gases;
        this.Olhinhos = novaAnaliseVisualItemPreTeste.Olhinhos;
        this.Analista = novaAnaliseVisualItemPreTeste.Analista;
        this.Observacao = novaAnaliseVisualItemPreTeste.Observacao;
    }
}

class AlteracaoFormula {
    constructor(novaAlteracaoFormula) {
        this.Codigo = novaAlteracaoFormula.Codigo;
        this.CertificadoCodigo = novaAlteracaoFormula.CertificadoCodigo;
        this.DataHora = novaAlteracaoFormula.DataHora;
        this.Amostra = novaAlteracaoFormula.Amostra;
        this.Analista = novaAlteracaoFormula.Analista;
        this.MotivoAlteracao = novaAlteracaoFormula.MotivoAlteracao;
        this.DescricaoAlteracao = novaAlteracaoFormula.DescricaoAlteracao;
    }
}

class Resultado {
    constructor(novoResultado) {
        this.Codigo = novoResultado.Codigo;
        this.CertificadoCodigo = novoResultado.CertificadoCodigo;
        this.Amostra = novoResultado.Amostra;
        this.DataInjecao = novoResultado.DataInjecao;
        this.HoraAnaliseFinal = novoResultado.HoraAnaliseFinal;
        this.AnalistaFechamento = novoResultado.AnalistaFechamento;
        this.Quantidade = novoResultado.Quantidade;
        this.AnalistaEtiquetas = novoResultado.AnalistaEtiquetas;
        this.AnaliseVisualResultado = novoResultado.AnaliseVisualResultado;
        this.TiposEspecificacoes = novoResultado.TiposEspecificacoes;
        this.Abrasao = novoResultado.Abrasao;
    }
}

class AnaliseVisualResultado {
    constructor(novaAnaliseVisualResultado) {
        this.Codigo = novaAnaliseVisualResultado.Codigo;
        this.ResultadoCodigo = novaAnaliseVisualResultado.ResultadoCodigo;
        this.Granulometria = novaAnaliseVisualResultado.Granulometria;
        this.Plastificacao = novaAnaliseVisualResultado.Plastificacao;
        this.Cor = novaAnaliseVisualResultado.Cor;
        this.MaDispersaoSilica = novaAnaliseVisualResultado.MaDispersaoSilica;
        this.FitaMonorosca = novaAnaliseVisualResultado.FitaMonorosca;
        this.Gases = novaAnaliseVisualResultado.Gases;
        this.Olhinhos = novaAnaliseVisualResultado.Olhinhos;
        this.Analista = novaAnaliseVisualResultado.Analista;
        this.Observacao = novaAnaliseVisualResultado.Observacao;
    }
}

class Reanalise {
    constructor(novaReanalise) {
        this.Codigo = novaReanalise.Codigo;
        this.ResultadoCodigo = novaReanalise.ResultadoCodigo;
        this.TiposEspecificacoes = novaReanalise.TiposEspecificacoes;
        this.Abrasao = novaReanalise.Abrasao;
    }
}

$('#loteReferencia, #observacao').blur(function () {
    model.Certificado.loteReferencia = $('#loteReferencia').val();
    model.Certificado.observacaoCertificado = $('#observacao').val();
    model.Update();
});

$('.updatePreTeste').blur(function () {
    model.Certificado.PreTeste.conferenciaCarga = $('#conferenciaCargaPreTesteSim').prop("checked");
    model.Certificado.PreTeste.conferenciaOleo = $('#conferenciaOleoPreTesteSim').prop("checked");
    model.Certificado.PreTeste.assinaturaConferenciaCarga = $('#assinaturaConferenciaCarga').val();
    model.Certificado.PreTeste.assinaturaConferenciaOleo = $('#assinaturaConferenciaOleo').val();
    model.UpdatePreTeste();
});

$('#cadastrarItemPreTeste').click(function () {
    model.novoItemPreTeste = new ItemPreTeste({
        Codigo: 0,
        PreTesteCodigo: model.Certificado.PreTeste.codigo,
        DataHoraInjecao: $('#DataHoraInjecaoItemPreTeste').val(),
        HoraTeste: $('#HoraTesteItemPreTeste').val(),
        HoraRetorno: $('#HoraRetornoItemPreTeste').val(),
        AssinaturaAnalista: $('#AssinaturaAnalistaItemPreTeste').val(),
        AssinaturaMonitorLider: $('#AssinaturaMonitorLiderItemPreTeste').val(),
        Observacao: $('#ObservacaoItemPreTeste').val(),
        AnaliseVisualItemPreTeste: {
            Granulometria: $("input[name=granulometriaAnaliseVisualPreTesteRadios]").filter(":checked").val(),
            Plastificacao: $("input[name=plastificacaoAnaliseVisualItemPreTesteRadios]").filter(":checked").val(),
            Cor: $("input[name=corAnaliseVisualItemPreTesteRadios]").filter(":checked").val(),
            MaDispersaoSilica: $("input[name=maDispSilicaAnaliseVisualItemPreTesteRadios]").filter(":checked").val(),
            FitaMonorosca: $("input[name=fitaMonoroscaAnaliseVisualItemPreTesteRadios]").filter(":checked").val(),
            Gases: $("input[name=gasesAnaliseVisualItemPreTesteRadios]").filter(":checked").val(),
            Olhinhos: $("input[name=olhinhosAnaliseVisualItemPreTesteRadios]").filter(":checked").val(),
            Analista: $("#analistaAnaliseVisualPreTeste").val(),
            Observacao: $("#observacaoAnaliseVisualPreTeste").val()
        },
        TiposEspecificacoes: [],
        Abrasao: null
    });

    // Validação cabeçalho pré-teste
    $('input[name=tiposEspecificacoesItemPreTeste]')
        .each(function (k, v) { model.novoItemPreTeste.TiposEspecificacoes.push({ Codigo: $(v).attr("id"), Valor: $(v).val() }); });

    if (model.Produto.tiposEspecificacoes.filter(function (t) { return t.codigo == '000005'; }).length > 0) {
        model.novoItemPreTeste.Abrasao = {
            Abrasividade: $("#abrasividadeAbrasaoPreTeste").val(),
            CPs: [
                {
                    MI: $("#cp1InicialAbrasaoPreTeste").val(),
                    MF: $("#cp1FinalAbrasaoPreTeste").val(),
                    Ordem: 1
                },
                {
                    MI: $("#cp2InicialAbrasaoPreTeste").val(),
                    MF: $("#cp2FinalAbrasaoPreTeste").val(),
                    Ordem: 2
                },
                {
                    MI: $("#cp3InicialAbrasaoPreTeste").val(),
                    MF: $("#cp3FinalAbrasaoPreTeste").val(),
                    Ordem: 3
                }
            ]
        }
    }

    if (!$("input[name=conferenciaCargaPreTeste]").filter(":checked").val()) {
        alert('Campo Conferência carga obrigatório');
        return false;
    } else {
        $('#validadeConferenciaCargaPreTeste').hide(true);
    }

    if ($('#assinaturaConferenciaCarga').val() == '') {
        alert('Campo Ass. Analista Conf. Carga obrigatório');
        $('#assinaturaConferenciaCarga').focus();
        return false;
    } else {
        $('#validadeAssinaturaConferenciaCarga').hide(true);
    }

    if (!$("input[name=conferenciaOleoPreTeste]").filter(":checked").val()) {
        alert('Campo Conferência óleo obrigatório');
        return false;
    } else {
        $('#validadeConferenciaOleoPreTeste').hide(true);
    }

    if ($('#assinaturaConferenciaOleo').val() == '') {
        alert('Campo Ass. Analista Conf. Óleo obrigatório');
        $('#assinaturaConferenciaOleo').focus();
        return false;
    } else {
        $('#validadeAssinaturaConferenciaOleo').hide(true);
    }

    // Validação campos item pré-teste
    if (model.novoItemPreTeste.DataHoraInjecao == '') {
        alert('Campo Data/hora injeção obrigatório');
        $('#DataHoraInjecaoItemPreTeste').focus();
        return false;
    } else {
        $('#validadeAssinaturaConferenciaCarga').hide(true);
    }

    if (model.novoItemPreTeste.HoraTeste == '') {
        alert('Campo Hora teste obrigatório');
        $('#HoraTesteItemPreTeste').focus();
        return false;
    } else {
        $('#validadeHoraTesteItemPreTeste').hide(true);
    }

    if (model.novoItemPreTeste.oraRetorno == '') {
        alert('Campo Hora de retorno obrigatório');
        $('#HoraRetornoItemPreTeste').focus();
        return false;
    } else {
        $('#validadeHoraRetornoItemPreTeste').hide(true);
    }

    if (model.novoItemPreTeste.AssinaturaAnalista == '') {
        alert('Campo Ass. analista obrigatório');
        $('#AssinaturaAnalistaItemPreTeste').focus();
        return false;
    } else {
        $('#validadeAssinaturaAnalistaItemPreTeste').hide(true);
    }

    if (model.novoItemPreTeste.AssinaturaMonitorLider == '') {
        alert('Campo Ass. monitor obrigatório');
        $('#AssinaturaMonitorLiderItemPreTeste').focus();
        return false;
    } else {
        $('#validadeAssinaturaMonitorLiderItemPreTeste').hide(true);
    }

    model.CadastrarItemPreTeste(CleanCadastroItemPreTeste);
});

$("input[name=granulometriaAnaliseVisualPreTesteRadios]").click(function () {
    if ($("input[name=granulometriaAnaliseVisualPreTesteRadios]").filter(":checked").val()) $('#granulometriaAnaliseVisualPreTesteRadios').hide(false);
});
$("input[name=plastificacaoAnaliseVisualItemPreTesteRadios]").click(function () {
    if ($("input[name=plastificacaoAnaliseVisualItemPreTesteRadios]").filter(":checked").val()) $('#plastificacaoAnaliseVisualPreTesteRadios').hide(false);
});
$("input[name=corAnaliseVisualItemPreTesteRadios]").click(function () {
    if ($("input[name=corAnaliseVisualItemPreTesteRadios]").filter(":checked").val()) $('#corAnaliseVisualPreTesteRadios').hide(false);
});
$("input[name=maDispSilicaAnaliseVisualItemPreTesteRadios]").click(function () {
    if ($("input[name=maDispSilicaAnaliseVisualItemPreTesteRadios]").filter(":checked").val()) $('#maDisposicaoSilicaAnaliseVisualPreTesteRadios').hide(false);
});
$("input[name=olhinhosAnaliseVisualItemPreTesteRadios]").click(function () {
    if ($("input[name=olhinhosAnaliseVisualItemPreTesteRadios]").filter(":checked").val()) $('#olhinhosAnaliseVisualPreTesteRadios').hide(false);
});
$("input[name=fitaMonoroscaAnaliseVisualItemPreTesteRadios]").click(function () {
    if ($("input[name=fitaMonoroscaAnaliseVisualItemPreTesteRadios]").filter(":checked").val()) $('#fitaMonoroscaAnaliseVisualPreTesteRadios').hide(false);
});
$("input[name=gasesAnaliseVisualItemPreTesteRadios]").click(function () {
    if ($("input[name=gasesAnaliseVisualItemPreTesteRadios]").filter(":checked").val()) $('#gasesAnaliseVisualPreTesteRadios').hide(false);
});

$('#modalAnaliseVisualItemPreTeste').click(function () {
    $("#granulometriaAnaliseVisualPreTesteRadios").show();
    $("#plastificacaoAnaliseVisualPreTesteRadios").show();
    $("#corAnaliseVisualPreTesteRadios").show();
    $("#maDisposicaoSilicaAnaliseVisualPreTesteRadios").show();
    $("#olhinhosAnaliseVisualPreTesteRadios").show();
    $("#fitaMonoroscaAnaliseVisualPreTesteRadios").show();
    $("#gasesAnaliseVisualPreTesteRadios").show();
});

$('#cadastrarAlteracaoFormula').click(function () {
    model.novaAlteracaoFormula = new AlteracaoFormula({
        Codigo: 0,
        CertificadoCodigo: model.Certificado.codigo,
        Amostra: $('#amostraAlteracaoFormula').val(),
        DataHora: $('#dataAlteracaoFormula').val(),
        Analista: $('#analistaAlteracaoFormula').val(),
        MotivoAlteracao: $('#motivoAlteracaoFormula').val(),
        DescricaoAlteracao: $('#descricaoAlteracaoFormula').val(),
    });

    if (!$('#amostraAlteracaoFormula').val()) {
        alert('Campo Amostra obrigatório');
        $('#amostraAlteracaoFormula').focus();
        return false;
    } else {
        $('#validadeAmostra').hide(true);
    }

    if (!$('#dataAlteracaoFormula').val()) {
        alert('Campo Data obrigatório');
        $('#dataAlteracaoFormula').focus();
        return false;
    } else {
        $('#validadeDataAlteracaoFormula').hide(true);
    }

    if (!$('#analistaAlteracaoFormula').val()) {
        alert('Campo Analista obrigatório');
        $('#analistaAlteracaoFormula').focus();
        return false;
    } else {
        $('#validadeAnalistaAlteracaoFormula').hide(true);
    }

    if (!$('#motivoAlteracaoFormula').val()) {
        alert('Campo Motivo obrigatório');
        $('#motivoAlteracaoFormula').focus();
        return false;
    } else {
        $('#validadeMotivoAlteracaoFormula').hide(true);
    }

    if (!$('#descricaoAlteracaoFormula').val()) {
        alert('Campo Descrição obrigatório');
        $('#descricaoAlteracaoFormula').focus();
        return false;
    } else {
        $('#validadeDescricaoAlteracaoFormula').hide(true);
    }

    model.CadastrarAlteracaoFormula(CleanCadastrarAlteracaoFormula);


});

$('#CadastrarResultado').click(function () {
    model.novoResultado = new Resultado({
        Codigo: 0,
        CertificadoCodigo: model.Certificado.codigo,
        Amostra: $('#amostraResultado').val(),
        DataInjecao: $('#DataInjecaoResultado').val(),
        HoraAnaliseFinal: $('#horaAnaliseFinalResultado').val(),
        AnalistaFechamento: $('#analistaFechamentoResultado').val(),
        Quantidade: $('#quantidadeResultado').val(),
        AnalistaEtiquetas: $('#analistaEtiquetasResultado').val(),
        AnaliseVisualResultado: {
            Granulometria: $("input[name=granulometriaAnaliseVisualResultadoRadios]").filter(":checked").val(),
            Plastificacao: $("input[name=plastificacaoAnaliseVisualResultadoRadios]").filter(":checked").val(),
            Cor: $("input[name=corAnaliseVisualResultadoRadios]").filter(":checked").val(),
            MaDispersaoSilica: $("input[name=maDispSilicaAnaliseVisualResultadoRadios]").filter(":checked").val(),
            FitaMonorosca: $("input[name=fitaMonoroscaAnaliseVisualResultadoRadios]").filter(":checked").val(),
            Gases: $("input[name=gasesAnaliseVisualResultadoRadios]").filter(":checked").val(),
            Olhinhos: $("input[name=olhinhosAnaliseVisualResultadoRadios]").filter(":checked").val(),
            Analista: $("#analistaAnaliseVisualResultado").val(),
            Observacao: $("#observacaoAnaliseVisualResultado").val()
        },
        TiposEspecificacoes: [],
        Abrasao: null
    });

    $('input[name=tiposEspecificacoesResultado]')
        .each(function (k, v) { model.novoResultado.TiposEspecificacoes.push({ Codigo: $(v).attr("id"), Valor: $(v).val() }); });

    if (model.Produto.tiposEspecificacoes.filter(function (t) { return t.codigo == '000005'; }).length > 0) {
        model.novoResultado.Abrasao = {
            Abrasividade: $("#abrasividadeAbrasaoResultado").val(),
            CPs: [
                {
                    MI: $("#cp1InicialAbrasaoResultado").val(),
                    MF: $("#cp1FinalAbrasaoResultado").val(),
                    Ordem: 1
                },
                {
                    MI: $("#cp2InicialAbrasaoResultado").val(),
                    MF: $("#cp2FinalAbrasaoResultado").val(),
                    Ordem: 2
                },
                {
                    MI: $("#cp3InicialAbrasaoResultado").val(),
                    MF: $("#cp3FinalAbrasaoResultado").val(),
                    Ordem: 3
                }
            ]
        }
    }

    // Validação campos item pré-teste
    if ($('#amostraResultado').val() == '') {
        alert('Campo Amostra obrigatório');
        $('#amostraResultado').focus();
        return false;
    } else {
        $('#validadeAmostraResultado').hide(true);
    }

    if ($('#DataInjecaoResultado').val() == '') {
        alert('Campo Data injeção obrigatório');
        $('#DataInjecaoResultado').focus();
        return false;
    } else {
        $('#validadeDataInjecaoResultado').hide(true);
    }

    if ($('#horaAnaliseFinalResultado').val() == '') {
        alert('Campo Hora análise final obrigatório');
        $('#horaAnaliseFinalResultado').focus();
        return false;
    } else {
        $('#validadeHoraAnaliseFinalResultado').hide(true);
    }

    if ($('#analistaFechamentoResultado').val() == '') {
        alert('Campo Analista (fechamento) obrigatório');
        $('#analistaFechamentoResultado').focus();
        return false;
    } else {
        $('#validadeAnalistaFechamentoResultado').hide(true);
    }

    if ($('#quantidadeResultado').val() == '') {
        alert('Campo Quantidade obrigatório');
        $('#quantidadeResultado').focus();
        return false;
    } else {
        $('#validadeQuantidadeResultado').hide(true);
    }

    if ($('#analistaEtiquetasResultado').val() == '') {
        alert('Campo Ass. monitor obrigatório');
        $('#analistaEtiquetasResultado').focus();
        return false;
    } else {
        $('#validadeAnalistaEtiquetasResultado').hide(true);
    }

    model.CadastrarResultado(CleanCadastroResultado);
});

$("input[name=granulometriaAnaliseVisualResultadoRadios]").click(function () {
    if ($("input[name=granulometriaAnaliseVisualResultadoRadios]").filter(":checked").val()) $('#granulometriaAnaliseVisualResultadoRadios').hide(false);
});
$("input[name=plastificacaoAnaliseVisualResultadoRadios]").click(function () {
    if ($("input[name=plastificacaoAnaliseVisualResultadoRadios]").filter(":checked").val()) $('#plastificacaoAnaliseVisualResultadoRadios').hide(false);
});
$("input[name=corAnaliseVisualResultadoRadios]").click(function () {
    if ($("input[name=corAnaliseVisualResultadoRadios]").filter(":checked").val()) $('#corAnaliseVisualResultadoRadios').hide(false);
});
$("input[name=maDispSilicaAnaliseVisualResultadoRadios]").click(function () {
    if ($("input[name=maDispSilicaAnaliseVisualResultadoRadios]").filter(":checked").val()) $('#maDisposicaoSilicaAnaliseVisualResultadoRadios').hide(false);
});
$("input[name=olhinhosAnaliseVisualResultadoRadios]").click(function () {
    if ($("input[name=olhinhosAnaliseVisualResultadoRadios]").filter(":checked").val()) $('#olhinhosAnaliseVisualResultadoRadios').hide(false);
});
$("input[name=fitaMonoroscaAnaliseVisualResultadoRadios]").click(function () {
    if ($("input[name=fitaMonoroscaAnaliseVisualResultadoRadios]").filter(":checked").val()) $('#fitaMonoroscaAnaliseVisualResultadoRadios').hide(false);
});
$("input[name=gasesAnaliseVisualResultadoRadios]").click(function () {
    if ($("input[name=gasesAnaliseVisualResultadoRadios]").filter(":checked").val()) $('#gasesAnaliseVisualResultadoRadios').hide(false);
});

$('#modalAnaliseVisualResultado').click(function () {
    $("#granulometriaAnaliseVisualResultadoRadios").show();
    $("#plastificacaoAnaliseVisualResultadoRadios").show();
    $("#corAnaliseVisualResultadoRadios").show();
    $("#maDisposicaoSilicaAnaliseVisualResultadoRadios").show();
    $("#olhinhosAnaliseVisualResultadoRadios").show();
    $("#fitaMonoroscaAnaliseVisualResultadoRadios").show();
    $("#gasesAnaliseVisualResultadoRadios").show();
});

$('.reanaliseResultado').click(function () {
    $('#resultadoCodigo').val($(this).val());
});

$('#CadastrarReanaliseResultado').click(function () {
    alert($('#modalResultadoCodigo').val());
    model.novaReanalise = new Reanalise({
        Codigo: 0,
        ResultadoCodigo: $('#modalResultadoCodigo').val(),
        TiposEspecificacoes: [],
        Abrasao: null
    });

    // Validação cabeçalho pré-teste
    $('input[name=tiposEspecificacoesReanalise]')
        .each(function (k, v) { model.novaReanalise.TiposEspecificacoes.push({ Codigo: $(v).attr("id"), Valor: $(v).val() }); });

    if (model.Produto.tiposEspecificacoes.filter(function (t) { return t.codigo == '000005'; }).length > 0) {
        model.novaReanalise.Abrasao = {
            Abrasividade: $("#abrasividadeReanaliseResultado").val(),
            CPs: [
                {
                    MI: $("#cp1InicialReanaliseResultado").val(),
                    MF: $("#cp1FinalReanaliseResultado").val(),
                    Ordem: 1
                },
                {
                    MI: $("#cp2InicialReanaliseResultado").val(),
                    MF: $("#cp2FinalReanaliseResultado").val(),
                    Ordem: 2
                },
                {
                    MI: $("#cp3InicialReanaliseResultado").val(),
                    MF: $("#cp3FinalReanaliseResultado").val(),
                    Ordem: 3
                }
            ]
        }
    }

    model.CadastrarReanaliseResultado(CleanCadastrarReanaliseResultado);
});

function CleanCadastroItemPreTeste() {

    $('#DataHoraInjecaoItemPreTeste').val('');
    $('#HoraTesteItemPreTeste').val('');
    $('#HoraRetornoItemPreTeste').val('');
    $('#AssinaturaAnalistaItemPreTeste').val('');
    $('#AssinaturaMonitorLiderItemPreTeste').val('');
    $('#ObservacaoItemPreTeste').val('');
    $('input[name=tiposEspecificacoesItemPreTeste]').val('');
    $("input[name=granulometriaAnaliseVisualPreTeste]").prop("checked", false);
    $("input[name=plastificacaoAnaliseVisualPreTeste]").prop("checked", false);
    $("input[name=corAnaliseVisualPreTeste]").prop("checked", false);
    $("input[name=maDispersaoSilicaAnaliseVisualPreTeste]").prop("checked", false);
    $("input[name=fitaMonoroscaAnaliseVisualPreTeste]").prop("checked", false);
    $("input[name=gasesAnaliseVisualPreTeste]").prop("checked", false);
    $("input[name=olhinhosAnaliseVisualPreTeste]").prop("checked", false);
    $("#analistaAnaliseVisualPreTeste").val('');
    $("#observacaoAnaliseVisualPreTeste").val('');
    $('#abrasividadeAbrasaoPreTeste').val('');
    $('#cp1InicialAbrasaoPreTeste').val('');
    $('#cp2InicialAbrasaoPreTeste').val('');
    $('#cp3InicialAbrasaoPreTeste').val('');
    $('#cp1FinalAbrasaoPreTeste').val('');
    $('#cp2FinalAbrasaoPreTeste').val('');
    $('#cp3FinalAbrasaoPreTeste').val('');

    model.novoItemPreTeste = null;
}

function CleanCadastrarReanaliseResultado() {

    $('input[name=tiposEspecificacoesReanalise]').val('');
    $('#abrasividadeReanaliseResultado').val('');
    $('#cp1InicialReanaliseResultado').val('');
    $('#cp2InicialReanaliseResultado').val('');
    $('#cp3InicialReanaliseResultado').val('');
    $('#cp1FinalReanaliseResultado').val('');
    $('#cp2FinalReanaliseResultado').val('');
    $('#cp3FinalReanaliseResultado').val('');

    model.novaReanalise = null;
}

function CleanCadastrarAlteracaoFormula() {

    $('#dataAlteracaoFormula').val('');
    $('#amostraAlteracaoFormula').val('');
    $('#analistaAlteracaoFormula').val('');
    $('#motivoAlteracaoFormula').val('');
    $('#descricaoAlteracaoFormula').val('');

    $('#validadeAmostra').show();
    $('#validadeDataAlteracaoFormula').show();
    $('#validadeAnalistaAlteracaoFormula').show();
    $('#validadeMotivoAlteracaoFormula').show();
    $('#validadeDescricaoAlteracaoFormula').show();

    model.novaAlteracaoFormula = null;
}

function CleanCadastroResultado() {

    $('#amostraResultado').val('');
    $('#DataInjecaoResultado').val('');
    $('#horaAnaliseFinalResultado').val('');
    $('#analistaFechamentoResultado').val('');
    $('#quantidadeResultado').val('');
    $('#analistaEtiquetasResultado').val('');
    $("input[name=granulometriaAnaliseVisualResultadoRadios]").prop("checked", false).val();
    $("input[name=plastificacaoAnaliseVisualResultadoRadios]").prop("checked", false).val();
    $("input[name=corAnaliseVisualResultadoRadios]").prop("checked", false).val();
    $("input[name=maDispSilicaAnaliseVisualResultadoRadios]").prop("checked", false).val();
    $("input[name=fitaMonoroscaAnaliseVisualResultadoRadios]").prop("checked", false).val();
    $("input[name=gasesAnaliseVisualResultadoRadios]").prop("checked", false).val();
    $("input[name=olhinhosAnaliseVisualResultadoRadios]").prop("checked", false).val();
    $("#analistaAnaliseVisualResultado").val('');
    $("#observacaoAnaliseVisualResultado").val('');
    $('input[name=tiposEspecificacoesResultado]').val('');
    $('#abrasividadeAbrasaoResultado').val('');
    $('#cp1InicialAbrasaoResultado').val('');
    $('#cp2InicialAbrasaoResultado').val('');
    $('#cp3InicialAbrasaoResultado').val('');
    $('#cp1FinalAbrasaoResultado').val('');
    $('#cp2FinalAbrasaoResultado').val('');
    $('#cp3FinalAbrasaoResultado').val('');

    model.novoResultado = null;
}

$('.modalAnaliseVisualPreTesteLeitura').click(function () {
    let itemPreTesteCodigo = $(this).val();
    let analiseVisualItemPreTeste = model.Certificado.PreTeste.itens.filter(function (i) { return i.codigo == itemPreTesteCodigo })[0].analiseVisualItemPreTeste;

    $.get('/Formulario/AnaliseVisualPreTesteLeitura', analiseVisualItemPreTeste, function (partial) {
        $('.analiseVisualPreTesteLeitura').html('');
        $('.analiseVisualPreTesteLeitura').append(partial);
    });
});

$('.modalAnaliseVisualResultadoLeitura').click(function () {
    let itemResultado = $(this).val();
    let analiseVisualResultado = model.Certificado.resultadosCertificado.filter(function (i) { return i.codigo == itemResultado })[0].analiseVisualResultado;

    $.get('/Formulario/AnaliseVisualResultadoLeitura', analiseVisualResultado, function (partial) {
        $('.analiseVisualResultadoLeitura').html('');
        $('.analiseVisualResultadoLeitura').append(partial);
    });
});

$('.modalAbrasaoItemPreTesteLeitura').click(function () {
    let abrasaoItem = $(this).val();
    let abrasaoItemPreTeste = model.Certificado.PreTeste.itens.filter(function (i) { return i.codigo == abrasaoItem })[0].abrasao;

    $.post('/Formulario/AbrasaoItemPreTesteLeitura', abrasaoItemPreTeste, function (partial) {
        $('.abrasaoItemPreTesteLeitura').html('');
        $('.abrasaoItemPreTesteLeitura').append(partial);
    });
});

$('.modalAbrasaoResultadoLeitura').click(function () {
    let abrasaoItem = $(this).val();
    let abrasaoResultado = model.Certificado.resultadosCertificado.filter(function (i) { return i.codigo == abrasaoItem })[0].abrasao;

    $.post('/Formulario/AbrasaoResultadoLeitura', abrasaoResultado, function (partial) {
        $('.abrasaoResultadoLeitura').html('');
        $('.abrasaoResultadoLeitura').append(partial);
    });
});