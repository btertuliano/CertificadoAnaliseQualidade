﻿namespace CertificadoAnaliseQualidade.DbAdapter.Clients;

public class ResultadoDto
{
    public string Z18_FILIAL { get; set; }
    public int Z18_CODRES { get; set; }
    public int Z18_CODSEQ { get; set; }
    public AnaliseVisualResultadoDto AnaliseVisualResultado { get; set; }
    public IEnumerable<ReanaliseResultadoDto> Reanalises { get; set; }
    public IEnumerable<TipoEspecificacaoDto> TiposEspecificacoes { get; set; }
    public string Z18_CODAM { get; set; }
    public string Z18_DTHINJ { get; set; }
    public string Z18_HAFIN { get; set; }
    public string Z18_AFECH { get; set; }
    public decimal Z18_QTD { get; set; }
    public string Z18_AETQ { get; set; }
}

public class AnaliseVisualResultadoDto
{
    public string Z23_FILIAL { get; set; }
    public int Z23_CODAVR { get; set; }
    public int Z23_CODRES { get; set; }
    public int Z23_COR { get; set; }
    public int Z23_MDS { get; set; }
    public int Z23_GRANU { get; set; }
    public int Z23_PLAST { get; set; }
    public int Z23_OLHIN { get; set; }
    public int Z23_FITAMO { get; set; }
    public int Z23_GASES { get; set; }
    public string Z23_ANALIS { get; set; }
    public string Z23_OBS { get; set; }
}

public class ReanaliseResultadoDto
{
    public string Z24_FILIAL { get; set; }
    public int Z24_CODREA { get; set; }
    public int Z24_CODRES { get; set; }
    public string Z24_CODESP { get; set; }
    public decimal Z24_VALESP { get; set; }
}

public class AbrasaoResultadoDto
{
    public string Z26_FILIAL { get; set; }
    public int Z26_CODAR { get; set; }
    public int Z26_CODRES { get; set; }
    public decimal Z26_MICP1 { get; set; }
    public decimal Z26_MICP2 { get; set; }
    public decimal Z26_MICP3 { get; set; }
    public decimal Z26_MFCP1 { get; set; }
    public decimal Z26_MFCP2 { get; set; }
    public decimal Z26_MFCP3 { get; set; }
    public decimal Z26_VALESP { get; set; }
    public decimal Z25_VALESP { get; set; }
}