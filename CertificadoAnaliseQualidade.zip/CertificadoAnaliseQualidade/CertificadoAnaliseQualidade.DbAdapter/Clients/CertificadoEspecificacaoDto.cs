﻿namespace CertificadoAnaliseQualidade.DbAdapter.Clients;

public class CertificadoEspecificacaoDto
{
    public int Z21_CODSEQ { get; set; }
    public int Z21_CODESP { get; set; }
    public decimal Z21_VALESP { get; set; }
}
