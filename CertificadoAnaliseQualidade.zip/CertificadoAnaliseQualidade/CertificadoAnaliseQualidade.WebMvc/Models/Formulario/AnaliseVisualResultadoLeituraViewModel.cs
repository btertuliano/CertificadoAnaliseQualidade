﻿using CertificadoAnaliseQualidade.Domain.Models;

namespace CertificadoAnaliseQualidade.WebMvc.Models.Formulario;

public class AnaliseVisualResultadoLeituraViewModel
{
    public AnaliseVisualResultado AnaliseVisualResultado { get; private set; }

    public AnaliseVisualResultadoLeituraViewModel(AnaliseVisualResultado analiseVisualResultado)
    {
        AnaliseVisualResultado = analiseVisualResultado;
    }

    private string AnaliseVisualResultadoCertificadoTipo(AnaliseVisualResultadoTipo analiseVisualResultadoTipo)
    {
        switch (analiseVisualResultadoTipo)
        {
            case AnaliseVisualResultadoTipo.Sim:
                return "Sim";
            case AnaliseVisualResultadoTipo.Nao:
                return "Não";
            case AnaliseVisualResultadoTipo.Na:
                return "N/A";
            default:
                return "N/A";
        }
    }
    public string Granulometria => AnaliseVisualResultadoCertificadoTipo(AnaliseVisualResultado.Granulometria);
    public string Plastificacao => AnaliseVisualResultadoCertificadoTipo(AnaliseVisualResultado.Plastificacao);
    public string Cor => AnaliseVisualResultadoCertificadoTipo(AnaliseVisualResultado.Cor);
    public string MaDispercaoSilica => AnaliseVisualResultadoCertificadoTipo(AnaliseVisualResultado.MaDispersaoSilica);
    public string Olhinhos => AnaliseVisualResultadoCertificadoTipo(AnaliseVisualResultado.Olhinhos);
    public string FitaMonorosca => AnaliseVisualResultadoCertificadoTipo(AnaliseVisualResultado.FitaMonorosca);
    public string Gases => AnaliseVisualResultadoCertificadoTipo(AnaliseVisualResultado.Gases);
}
