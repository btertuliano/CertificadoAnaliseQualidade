﻿namespace CertificadoAnaliseQualidade.DbAdapter.Clients;

public class AlteracaoFormulaDto
{
    public string Z19_FILIAL { get; set; }
    public int Z19_CODALT { get; set; }
    public int Z19_CODSEQ { get; set; }
    public string Z19_DTALT { get; set; }
    public string Z19_SUBLOT { get; set; }
    public string Z19_ANALIS { get; set; }
    public string Z19_MALT { get; set; }
    public string Z19_DESCAL { get; set; }
}
