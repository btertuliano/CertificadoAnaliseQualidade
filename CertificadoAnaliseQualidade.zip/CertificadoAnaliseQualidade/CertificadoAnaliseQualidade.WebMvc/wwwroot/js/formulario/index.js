﻿$('.form-select').select2({
    theme: "bootstrap-5",
    width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
    placeholder: $(this).data('placeholder'),
    allowClear: true
});

$('#produto').change(function () {
    
    if ($('#produto :selected').val() != '') {

        $.get('/Formulario/ObterCertificadoPorLote', { lote: $('#produto :selected').val() }, function (codigoCertificado) {

            if (codigoCertificado == 0) {
                alertaModal('Atenção', 'Deseja criar um novo certificado?', function () {
                    var lote = $('#produto :selected').val();

                    $.get('/Formulario/Novo', { lote: lote }, function (codigo) {
                        window.location.href = '/Formulario/Cadastro/' + codigo;
                    });
                });
            } else {
                alertaModal('Atenção', 'Lote já possui certificado cadastrado, deseja continuar?', function () {
                    window.location.href = '/Formulario/Cadastro/' + codigoCertificado;
                });
            }
            $('#botaoAlerta').trigger('click');
        });
    }
});