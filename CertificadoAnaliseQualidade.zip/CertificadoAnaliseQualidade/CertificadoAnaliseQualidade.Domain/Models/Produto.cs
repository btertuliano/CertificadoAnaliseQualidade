﻿using CertificadoAnaliseQualidade.Domain.Models.Abstracts;

namespace CertificadoAnaliseQualidade.Domain.Models;

public class Produto
{
    /// <summary>
    /// Código do produto
    /// </summary>
    public string Codigo { get; set; }
    
    /// <summary>
    /// Nome do produto
    /// </summary>
    public string Nome { get; set; }
    
    /// <summary>
    /// Lote de localização do produto
    /// </summary>
    public string Lote { get; set; }
    
    /// <summary>
    /// Data que o produto foi fabricado
    /// </summary>
    public DateTime DataFabricacao { get; set; }

    /// <summary>
    /// Lista de especificações do produto
    /// </summary>
    public IEnumerable<TipoEspecificacao> TiposEspecificacoes { get; set; }
}