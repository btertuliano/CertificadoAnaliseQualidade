﻿namespace CertificadoAnaliseQualidade.Domain.Models;

public class PreTeste
{
    /// <summary>
    /// Código do pré-teste
    /// </summary>
    public int Codigo { get; set; }

    /// <summary>
    /// Verifica se a carga foi conferida
    /// </summary>
    public bool ConferenciaCarga { get; set; }

    /// <summary>
    /// Assinatura do responsável pela conferência da carga
    /// </summary>
    public string AssinaturaConferenciaCarga { get; set; }

    /// <summary>
    /// Verifica se o óleo foi conferido
    /// </summary>
    public bool ConferenciaOleo { get; set; }

    /// <summary>
    /// Assinatura do responsável pela conferência do óleo
    /// </summary>
    public string AssinaturaConferenciaOleo { get; set; }

    /// <summary>
    /// Itens contendo os dados que complementam o pré-teste
    /// </summary>
    public IEnumerable<ItemPreTeste> Itens { get; set; }
}