﻿function alertaModal(titulo, mensagem, funcaoAlertaSim) {
    $('.modal-title').text(titulo);
    $('.modal-body').text(mensagem);

    $('#alertaModalSim').click(funcaoAlertaSim);
}