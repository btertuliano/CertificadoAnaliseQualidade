﻿namespace CertificadoAnaliseQualidade.DbAdapter.Clients;

public class CPDto
{
    public string Z27_FILIAL { get; set; }
    public int Z27_CODITM { get; set; }
    public decimal Z27_MICP1 { get; set; }
    public decimal Z27_MICP2 { get; set; }
    public decimal Z27_MICP3 { get; set; }
    public decimal Z27_MFCP1 { get; set; }
    public decimal Z27_MFCP2 { get; set; }
    public decimal Z27_MFCP3 { get; set; }

}
