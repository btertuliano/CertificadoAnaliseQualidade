﻿using CertificadoAnaliseQualidade.Domain.Models.Abstracts;

namespace CertificadoAnaliseQualidade.Domain.Models;

public class Reanalise
{
    /// <summary>
    /// Código da reanálise
    /// </summary>
    public int Codigo { get; set; }

    /// <summary>
    /// Código do resultado
    /// </summary>
    public int ResultadoCodigo { get; set; }

    /// <summary>
    /// Lista de especificações do produto
    /// </summary>
    public IEnumerable<TipoEspecificacao> TiposEspecificacoes { get; set; }

    /// <summary>
    /// Dados da abrasão da reanálise
    /// </summary>
    public Abrasao Abrasao { get; set; }
}
