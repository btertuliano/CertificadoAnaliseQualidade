﻿using CertificadoAnaliseQualidade.Application;
using CertificadoAnaliseQualidade.Domain.Services;

namespace Microsoft.Extensions.DependencyInjection;

public static class ApplicationServiceCollectionExtensions
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        if (services is null)
        {
            throw new ArgumentNullException(nameof(services));
        }

        services.AddScoped<IProdutosService, ProdutosService>();
        services.AddScoped<ICertificadosService, CertificadosService>();

        return services;
    }
}
