﻿using CertificadoAnaliseQualidade.Domain.Adapters;
using CertificadoAnaliseQualidade.Domain.Models;
using CertificadoAnaliseQualidade.Domain.Services;
using Microsoft.Extensions.Logging;

namespace CertificadoAnaliseQualidade.Application;

public class CertificadosService : ICertificadosService
{
    private readonly IDbAdapter dbAdapter;
    private readonly ILogger logger;

    public CertificadosService(IDbAdapter dbAdapter, ILoggerFactory loggerFactory)
    {
        this.dbAdapter = dbAdapter
            ?? throw new ArgumentNullException(nameof(dbAdapter));

        logger = loggerFactory?.CreateLogger<ProdutosService>()
            ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task AtualizarCertificadoAsync(Certificado certificado)
    {
        logger.LogInformation($"Realizando chamada ao método {nameof(AtualizarCertificadoAsync)}");

        await dbAdapter.AtualizarCertificadoAsync(certificado);

        logger.LogInformation($"Chamada ao método {nameof(AtualizarCertificadoAsync)} realizada");
    }

    public async Task AtualizarPreTesteAsync(PreTeste preTeste)
    {
        logger.LogInformation($"Realizando chamada ao método {nameof(AtualizarPreTesteAsync)}");

        await dbAdapter.AtualizarPreTesteAsync(preTeste);

        logger.LogInformation($"Chamada ao método {nameof(AtualizarPreTesteAsync)} realizada");
    }

    public async Task<Certificado> CadastrarCertificadoAsync(Certificado certificado)
    {
        logger.LogInformation("Realizando chamada ao método {CadastrarCertificadoAsync}", nameof(CadastrarCertificadoAsync));

        var novoCertificado = await dbAdapter.CadastrarCertificadoAsync(certificado);

        novoCertificado.PreTeste = new PreTeste();
        novoCertificado.PreTeste = await dbAdapter.CadastrarPreTeste(novoCertificado);

        logger.LogInformation("Chamada ao método {CadastrarCertificadoAsync} realizada", nameof(CadastrarCertificadoAsync));

        return novoCertificado;
    }

    public async Task<ItemPreTeste> CadastrarItemPreTeste(ItemPreTeste itemPreTeste)
    {
        logger.LogInformation($"Realizando chamada ao método {nameof(CadastrarItemPreTeste)}");

        var novoItemPreTeste = await dbAdapter.CadastrarItemPreTeste(itemPreTeste);

        logger.LogInformation($"Chamada ao método {nameof(CadastrarItemPreTeste)} realizada");

        return novoItemPreTeste;
    }

    public async Task<Certificado> ObterCertificadoAsync(int codigo)
    {
        logger.LogInformation($"Realizando chamada ao método {nameof(ObterCertificadoAsync)}");

        var certificado = await dbAdapter.ObterCertificadoAsync(codigo);

        logger.LogInformation($"Chamada ao método {nameof(ObterCertificadoAsync)} realizada");

        return certificado;
    }

    public async Task<Certificado> ObterCertificadoPorLoteAsync(string lote)
    {
        logger.LogInformation("Realizando chamada ao método {ObterCertificadoPorLoteAsync}", nameof(ObterCertificadoPorLoteAsync));

        var certificado = await dbAdapter.ObterCertificadoPorLoteAsync(lote);

        logger.LogInformation("Chamada ao método {ObterCertificadoPorLoteAsync} realizada", nameof(ObterCertificadoPorLoteAsync));

        return certificado;
    }

    public async Task<AlteracaoFormula> CadastrarAlteracaoFormulaAsync(AlteracaoFormula alteracaoFormula)
    {
        logger.LogInformation($"Realizando chamada ao método {nameof(CadastrarAlteracaoFormulaAsync)}");

        var alteracoesFormula = await dbAdapter.CadastrarAlteracaoFormulaAsync(alteracaoFormula);

        logger.LogInformation($"Chamada ao método {nameof(CadastrarAlteracaoFormulaAsync)} realizada");

        return alteracoesFormula;
    }

    public async Task<ResultadoCertificado> CadastrarResultado(ResultadoCertificado resultadoCertificado)
    {
        logger.LogInformation($"Realizando chamada ao método {nameof(CadastrarResultado)}");

        var resultadosCertificado = await dbAdapter.CadastrarResultado(resultadoCertificado);

        logger.LogInformation($"Chamada ao método {nameof(CadastrarResultado)} realizada");

        return resultadosCertificado;
    }

    public async Task<Reanalise> CadastrarReanaliseResultado(Reanalise reanalise)
    {
        logger.LogInformation($"Realizando chamada ao método {nameof(CadastrarReanaliseResultado)}");

        var reanaliseResultado = await dbAdapter.CadastrarReanaliseResultado(reanalise);

        logger.LogInformation($"Chamada ao método {nameof(CadastrarReanaliseResultado)} realizada");

        return reanaliseResultado;
    }
}
