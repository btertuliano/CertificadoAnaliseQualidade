﻿using CertificadoAnaliseQualidade.DbAdapter.Clients;
using CertificadoAnaliseQualidade.Domain.Models;
using CertificadoAnaliseQualidade.Domain.Models.Abstracts;
using Dapper;

namespace CertificadoAnaliseQualidade.DbAdapter;

public partial class DbAdapter
{
    private async Task<IEnumerable<ItemPreTeste>> ObterItensPreTesteAsync(int preTesteCodigo)
    {
        var query = @"SELECT
	                    ItemPreTeste.Z22_CODITM, ItemPreTeste.Z22_CODPTE, ItemPreTeste.Z22_DTHINJ,
	                    ItemPreTeste.Z22_HTESTE, ItemPreTeste.Z22_HRET, ItemPreTeste.Z22_AANALT,
	                    ItemPreTeste.Z22_AMOLI, ItemPreTeste.Z22_AMOLI, ItemPreTeste.Z22_OBS,
	                    AnaliseVisualItemPreTeste.Z20_CODAV,AnaliseVisualItemPreTeste.Z20_CODITM,
	                    AnaliseVisualItemPreTeste.Z20_COR,AnaliseVisualItemPreTeste.Z20_MDS,
	                    AnaliseVisualItemPreTeste.Z20_GRANU,AnaliseVisualItemPreTeste.Z20_PLAST,
	                    AnaliseVisualItemPreTeste.Z20_OLHIN,AnaliseVisualItemPreTeste.Z20_FITAMO,
	                    AnaliseVisualItemPreTeste.Z20_GASES,AnaliseVisualItemPreTeste.Z20_ANALIS,
	                    AnaliseVisualItemPreTeste.Z20_OBS
                      FROM Z22010 AS ItemPreTeste
                        LEFT JOIN Z20010 AS AnaliseVisualItemPreTeste ON(ItemPreTeste.Z22_CODITM = AnaliseVisualItemPreTeste.Z20_CODITM)
                      WHERE Z22_CODPTE = @Z22_CODPTE";

        var itensPreTeste = await dbConnection.QueryAsync<ItemPreTesteDto, AnaliseVisualItemPreTesteDto, ItemPreTeste>(query,
            (itemPreTesteDto, analiseVisualItemPreTesteDto) =>
            {
                itemPreTesteDto.AnaliseVisualItemPreTeste = analiseVisualItemPreTesteDto ??
                    new AnaliseVisualItemPreTesteDto();

                return mapper.Map<ItemPreTeste>(itemPreTesteDto);
            }
            , splitOn: "Z20_CODAV",
            param: new { Z22_CODPTE = preTesteCodigo });

        foreach (var itemPreTeste in itensPreTeste)
        {
            itemPreTeste.TiposEspecificacoes =
                await ObterTiposEspecificaoesItensPreTesteAsync(itemPreTeste.Codigo);

            itemPreTeste.Abrasao = await ObterAbrasaoItensPreTesteAsync(itemPreTeste.Codigo);
        }


        return itensPreTeste;
    }

    private async Task<Abrasao> ObterAbrasaoItensPreTesteAsync(int itemPreTesteCodigo)
    {
        var query = @"SELECT
                        AbrasaoItemPreTeste.Z27_CODITM,
                        AbrasaoItemPreTeste.Z27_MICP1, AbrasaoItemPreTeste.Z27_MICP2,
                        AbrasaoItemPreTeste.Z27_MICP3, AbrasaoItemPreTeste.Z27_MFCP1,
                        AbrasaoItemPreTeste.Z27_MFCP2, AbrasaoItemPreTeste.Z27_MFCP3,
                        EspItmPreTeste.Z21_VALESP
                      FROM Z27010 AS AbrasaoItemPreTeste
                        INNER JOIN Z21010 EspItmPreTeste ON(EspItmPreTeste.D_E_L_E_T_ = ''
                            AND AbrasaoItemPreTeste.Z27_CODITM = EspItmPreTeste.Z21_CODITM)
                      WHERE AbrasaoItemPreTeste.D_E_L_E_T_ = '' 
                        AND AbrasaoItemPreTeste.Z27_CODITM = @Z27_CODITM
                        AND EspItmPreTeste.Z21_CODESP = '000005'";

        var abrasoesItemPreTesteDto = await dbConnection.QueryAsync<AbrasaoItemPreTesteDto>(query, new { Z27_CODITM = itemPreTesteCodigo });

        var abrasaoItemPreTesteDto = abrasoesItemPreTesteDto.SingleOrDefault();

        Abrasao abrasaoItemPreTeste = null;

        if (abrasaoItemPreTesteDto is not null)
        {
            abrasaoItemPreTeste = new Abrasao
            {

                Abrasividade = abrasaoItemPreTesteDto.Z21_VALESP,
                CPs = new List<CP>
                {
                    new CP
                    {
                        MI = abrasaoItemPreTesteDto.Z27_MICP1,
                        MF = abrasaoItemPreTesteDto.Z27_MFCP1,
                        Ordem = 1
                    },
                    new CP
                    {
                        MI = abrasaoItemPreTesteDto.Z27_MICP2,
                        MF = abrasaoItemPreTesteDto.Z27_MFCP2,
                        Ordem = 2
                    },
                    new CP
                    {
                        MI = abrasaoItemPreTesteDto.Z27_MICP3,
                        MF = abrasaoItemPreTesteDto.Z27_MFCP3,
                        Ordem = 3
                    }
                }
            };
        }

        return abrasaoItemPreTeste;
    }

    private async Task<Abrasao> ObterAbrasaoResultadoAsync(int resultadoCertificado)
    {
        var query = @"SELECT
                        AbrasaoResultado.Z26_CODRES,
                        AbrasaoResultado.Z26_MICP1, AbrasaoResultado.Z26_MICP2,
                        AbrasaoResultado.Z26_MICP3, AbrasaoResultado.Z26_MFCP1,
                        AbrasaoResultado.Z26_MFCP2, AbrasaoResultado.Z26_MFCP3,
                        EspRes.Z25_VALESP
                      FROM Z26010 AS AbrasaoResultado
                        INNER JOIN Z25010 EspRes ON(EspRes.D_E_L_E_T_ = ''
                            AND AbrasaoResultado.Z26_CODRES = EspRes.Z25_CODRES)
                      WHERE AbrasaoResultado.D_E_L_E_T_ = '' 
                        AND AbrasaoResultado.Z26_CODRES = @Z26_CODRES
                        AND EspRes.Z25_CODESP = '000005'";

        var abrasoesResultadoDto = await dbConnection.QueryAsync<AbrasaoResultadoDto>(query, new { Z26_CODRES = resultadoCertificado });

        var abrasaoResultadoDto = abrasoesResultadoDto.SingleOrDefault();

        Abrasao abrasaoResultado = null;

        if (abrasaoResultadoDto is not null)
        {
            abrasaoResultado = new Abrasao
            {

                Abrasividade = abrasaoResultadoDto.Z25_VALESP,
                CPs = new List<CP>
                {
                    new CP
                    {
                        MI = abrasaoResultadoDto.Z26_MICP1,
                        MF = abrasaoResultadoDto.Z26_MFCP1,
                        Ordem = 1
                    },
                    new CP
                    {
                        MI = abrasaoResultadoDto.Z26_MICP2,
                        MF = abrasaoResultadoDto.Z26_MFCP2,
                        Ordem = 2
                    },
                    new CP
                    {
                        MI = abrasaoResultadoDto.Z26_MICP3,
                        MF = abrasaoResultadoDto.Z26_MFCP3,
                        Ordem = 3
                    }
                }
            };
        }

        return abrasaoResultado;
    }

    private async Task<IEnumerable<AlteracaoFormula>> ObterAlteracoesFormulasAsync(int certificadoCodigo)
    {
        var query = @"SELECT
	                    alteracaoFormula.Z19_CODSEQ,
	                    alteracaoFormula.Z19_DTALT,
	                    alteracaoFormula.Z19_SUBLOT,
	                    alteracaoFormula.Z19_ANALIS,
	                    alteracaoFormula.Z19_MALT,
	                    alteracaoFormula.Z19_DESCAL
                    FROM Z19010 alteracaoFormula
                    WHERE alteracaoFormula.D_E_L_E_T_ = ''
                        AND Z19_CODSEQ = @Z19_CODSEQ";

        var alteracaoFormulaDto = await dbConnection.QueryAsync<AlteracaoFormulaDto>(query, new { Z19_CODSEQ = certificadoCodigo });

        var alteracoesFormulas = mapper.Map<IEnumerable<AlteracaoFormula>>(alteracaoFormulaDto);

        return alteracoesFormulas;
    }

    private async Task<IEnumerable<AlteracaoFormula>> ObterAlteracaoFormulaPorCodigoAsync(int certificadoCodigo, int alteracaoFormulaCodigo)
    {
        var query = @"SELECT
	                    alteracaoFormula.Z19_CODSEQ,
	                    alteracaoFormula.Z19_DTALT,
	                    alteracaoFormula.Z19_SUBLOT,
	                    alteracaoFormula.Z19_ANALIS,
	                    alteracaoFormula.Z19_MALT,
	                    alteracaoFormula.Z19_DESCAL
                    FROM Z19010 alteracaoFormula
                    WHERE alteracaoFormula.D_E_L_E_T_ = ''
                        AND Z19_CODSEQ = @Z19_CODSEQ AND Z19_CODALT = @Z19_CODALT";

        var alteracaoFormulaDto = await dbConnection.QueryAsync<AlteracaoFormulaDto>(query, new { Z19_CODSEQ = certificadoCodigo, Z19_CODALT = alteracaoFormulaCodigo });

        var alteracoesFormulas = mapper.Map<IEnumerable<AlteracaoFormula>>(alteracaoFormulaDto);

        return alteracoesFormulas;
    }


    /*
     SELECT
	    resultadoCertificado.Z18_CODAM,
	    resultadoCertificado.Z18_CODSEQ,
	    resultadoCertificado.Z18_DTHINJ,
	    resultadoCertificado.Z18_HAFIN,
	    resultadoCertificado.Z18_AFECH,
	    resultadoCertificado.Z18_QTD,
		resultadoCertificado.Z18_AETQ,
		AnaliseVisualResultado.Z23_CODAVR, AnaliseVisualResultado.Z23_CODRES,
	    AnaliseVisualResultado.Z23_COR, AnaliseVisualResultado.Z23_MDS,
	    AnaliseVisualResultado.Z23_GRANU, AnaliseVisualResultado.Z23_PLAST,
	    AnaliseVisualResultado.Z23_OLHIN, AnaliseVisualResultado.Z23_FITAMO,
	    AnaliseVisualResultado.Z23_GASES, AnaliseVisualResultado.Z23_ANALIS,
	    AnaliseVisualResultado.Z23_OBS,
		AbrasaoResultado.Z26_MICP1, AbrasaoResultado.Z26_MICP2, AbrasaoResultado.Z26_MICP3,
		AbrasaoResultado.Z26_MFCP1, AbrasaoResultado.Z26_MFCP2, AbrasaoResultado.Z26_MFCP3,
		TpEspecResultado.Z25_CODESP, TpEspecResultado.Z25_VALESP
    FROM Z18010 resultadoCertificado
		LEFT JOIN Z25010 AS TpEspecResultado ON TpEspecResultado.D_E_L_E_T_ = ''
			AND resultadoCertificado.Z18_CODRES = TpEspecResultado.Z25_CODRES
		LEFT JOIN Z23010 AS AnaliseVisualResultado ON AnaliseVisualResultado.D_E_L_E_T_ = ''
			AND resultadoCertificado.Z18_CODRES = AnaliseVisualResultado.Z23_CODRES
		LEFT JOIN Z26010 AS AbrasaoResultado ON AbrasaoResultado.D_E_L_E_T_ = ''
			AND resultadoCertificado.Z18_CODRES = AbrasaoResultado.Z26_CODRES
     
     */

    private async Task<IEnumerable<ResultadoCertificado>> ObterResultadoCertificadoAsync(int certificadoCodigo)
    {
        var query = @"SELECT
                        resultadoCertificado.Z18_CODRES,
	                    resultadoCertificado.Z18_CODAM,
	                    resultadoCertificado.Z18_CODSEQ,
	                    resultadoCertificado.Z18_DTHINJ,
	                    resultadoCertificado.Z18_HAFIN,
	                    resultadoCertificado.Z18_AFECH,
	                    resultadoCertificado.Z18_QTD,
						resultadoCertificado.Z18_AETQ,
                        AnaliseVisualResultado.Z23_CODAVR, AnaliseVisualResultado.Z23_CODRES,
	                    AnaliseVisualResultado.Z23_COR, AnaliseVisualResultado.Z23_MDS,
	                    AnaliseVisualResultado.Z23_GRANU, AnaliseVisualResultado.Z23_PLAST,
	                    AnaliseVisualResultado.Z23_OLHIN, AnaliseVisualResultado.Z23_FITAMO,
	                    AnaliseVisualResultado.Z23_GASES, AnaliseVisualResultado.Z23_ANALIS,
	                    AnaliseVisualResultado.Z23_OBS
                    FROM Z18010 resultadoCertificado
						LEFT JOIN Z23010 AS AnaliseVisualResultado ON(AnaliseVisualResultado.D_E_L_E_T_ = ''
							AND resultadoCertificado.Z18_CODRES = AnaliseVisualResultado.Z23_CODRES)
                    WHERE resultadoCertificado.D_E_L_E_T_ = ''
                        AND Z18_CODSEQ = @Z18_CODSEQ";

        var resultadosCertificado = await dbConnection.QueryAsync<ResultadoDto, AnaliseVisualResultadoDto, ResultadoCertificado>(query,
            (resultadoDto, analiseVisualResultadoDto) =>
            {
                var resultadoCertificado = mapper.Map<ResultadoCertificado>(resultadoDto);
                var analiseVisualResultado = mapper.Map<AnaliseVisualResultado>(analiseVisualResultadoDto);

                resultadoCertificado.AnaliseVisualResultado = analiseVisualResultado;

                return resultadoCertificado;
            }
            , splitOn: "Z18_AETQ",
            param: new { Z18_CODSEQ = certificadoCodigo });


        foreach (var resultado in resultadosCertificado)
        {
            resultado.TiposEspecificacoes =
                await ObterTiposEspecificaoesResultadoAsync(resultado.Codigo);

            resultado.Abrasao =
                await ObterAbrasaoResultadoAsync(resultado.Codigo);
        }

        return resultadosCertificado;
    }

    private async Task<IEnumerable<TipoEspecificacao>> ObterTiposEspecificaoesItensPreTesteAsync(int itemPreTesteCodigo)
    {
        var query = @"SELECT
	                    TpEspecItPreTeste.Z21_CODESP AS Z11_COD, DescTipoEspec.Z11_DESC, TpEspecItPreTeste.Z21_VALESP AS Z12_VALOR
                      FROM Z21010 AS TpEspecItPreTeste
						INNER JOIN Z11010 AS DescTipoEspec ON (DescTipoEspec.D_E_L_E_T_ = ''
							AND TpEspecItPreTeste.Z21_CODESP = DescTipoEspec.Z11_COD)
                      WHERE TpEspecItPreTeste.Z21_CODITM = @Z21_CODITM";

        var tiposEspecificacoesDto = await dbConnection
            .QueryAsync<TipoEspecificacaoDto>(query, new { Z21_CODITM = itemPreTesteCodigo });

        var tiposEspecificacoes = mapper.Map<IEnumerable<TipoEspecificacao>>(tiposEspecificacoesDto);

        return tiposEspecificacoes;
    }

    private async Task<IEnumerable<TipoEspecificacao>> ObterTiposEspecificaoesResultadoAsync(int resultadoCodigo)
    {
        var query = @"SELECT
	                    TpEspecResultado.Z25_CODESP AS Z11_COD, DescTipoEspec.Z11_DESC, Z25_VALESP AS Z12_VALOR
                      FROM Z25010 AS TpEspecResultado
					    INNER JOIN Z11010 AS DescTipoEspec ON (DescTipoEspec.D_E_L_E_T_ = ''
						    AND TpEspecResultado.Z25_CODESP = DescTipoEspec.Z11_COD)
                      WHERE TpEspecResultado.Z25_CODRES = @Z25_CODRES";

        var tiposEspecificacoesDto = await dbConnection
            .QueryAsync<TipoEspecificacaoDto>(query, new { Z25_CODRES = resultadoCodigo });

        var tiposEspecificacoes = mapper.Map<IEnumerable<TipoEspecificacao>>(tiposEspecificacoesDto);

        return tiposEspecificacoes;
    }

    private async Task CadastrarTiposEspecificacoesItemPreTeste(ItemPreTeste itemPreTeste)
    {
        var query = @"DELETE FROM Z21010 WHERE Z21_CODITM = @Z21_CODITM";

        await dbConnection.ExecuteAsync(query, new { Z21_CODITM = itemPreTeste.Codigo });

        query = @"INSERT INTO Z21010
                  (Z21_FILIAL, Z21_CODITM, Z21_CODESP, Z21_VALESP, R_E_C_N_O_)
                  VALUES
                  (@Z21_FILIAL, @Z21_CODITM, @Z21_CODESP, @Z21_VALESP, (SELECT IDENT_CURRENT('Z21010')));";

        var parameters =
            itemPreTeste.TiposEspecificacoes
                .Select(t =>
                {
                    var parameters = new
                    {
                        Z21_FILIAL = "0101",
                        Z21_CODITM = itemPreTeste.Codigo,
                        Z21_CODESP = t.Codigo,
                        Z21_VALESP = t.Valor
                    };

                    return parameters;
                }).ToList();

        if (itemPreTeste.Abrasao is not null)
        {
            parameters.Add(new
            {
                Z21_FILIAL = "0101",
                Z21_CODITM = itemPreTeste.Codigo,
                Z21_CODESP = "000005",
                Z21_VALESP = itemPreTeste.Abrasao.Abrasividade
            });

            await CadastrarAbrasaoItemPreTeste(itemPreTeste);
        }

        await dbConnection.ExecuteAsync(query, parameters);
    }

    private async Task CadastrarAnaliseVisualItemPreTeste(ItemPreTeste itemPreTeste)
    {
        var query = @"INSERT INTO Z20010
                        (Z20_FILIAL, Z20_CODITM, Z20_COR, Z20_MDS, Z20_GRANU, 
                        Z20_PLAST, Z20_OLHIN, Z20_FITAMO, Z20_GASES, 
                        Z20_ANALIS, Z20_OBS, R_E_C_N_O_)
                    VALUES
                        (@Z20_FILIAL, @Z20_CODITM, @Z20_COR, @Z20_MDS, @Z20_GRANU, 
                        @Z20_PLAST, @Z20_OLHIN, @Z20_FITAMO, @Z20_GASES, 
                        @Z20_ANALIS, @Z20_OBS, (SELECT IDENT_CURRENT('Z20010')))";

        var analiseVisualItemPreTesteDto = mapper.Map<AnaliseVisualItemPreTesteDto>(itemPreTeste.AnaliseVisualItemPreTeste);

        var parameters = new DynamicParameters(analiseVisualItemPreTesteDto);

        parameters.Add("Z20_FILIAL", "0101");

        await dbConnection.ExecuteAsync(query, parameters);
    }

    private async Task CadastrarAnaliseVisualResultado(ResultadoCertificado resultadoCertificado)
    {
        var query = @"INSERT INTO Z23010
                        (Z23_FILIAL, Z23_CODRES, Z23_COR, Z23_MDS, Z23_GRANU,
                        Z23_PLAST, Z23_OLHIN, Z23_FITAMO, Z23_GASES, 
                        Z23_ANALIS, Z23_OBS, R_E_C_N_O_)
                    VALUES
                        (@Z23_FILIAL, @Z23_CODRES, @Z23_COR, @Z23_MDS, @Z23_GRANU,
                        @Z23_PLAST, @Z23_OLHIN, @Z23_FITAMO, @Z23_GASES, 
                        @Z23_ANALIS, @Z23_OBS, (SELECT IDENT_CURRENT('Z23010')))";

        var analiseVisualResultadoDto = mapper.Map<AnaliseVisualResultadoDto>(resultadoCertificado.AnaliseVisualResultado);

        await dbConnection.ExecuteAsync(query, analiseVisualResultadoDto);
    }

    private async Task CadastrarAbrasaoReanalise(Reanalise reanalise)
    {
        var query = @"INSERT INTO Z28010
                        (Z28_FILIAL, Z28_CODRES, Z28_MICP1, Z28_MICP2, Z28_MICP3, 
                        Z28_MFCP1, Z28_MFCP2, Z28_MFCP3, R_E_C_N_O_)
                    VALUES
                        (@Z28_FILIAL, @Z28_CODRES, @Z28_MICP1, @Z28_MICP2, @Z28_MICP3, 
                        @Z28_MFCP1, @Z28_MFCP2, @Z28_MFCP3, (SELECT IDENT_CURRENT('Z28010')))";

        var cpReanaliseDto = new CPReanaliseDto
        {
            Z28_FILIAL = "0101",
            Z28_CODRES = reanalise.ResultadoCodigo,
            Z28_MICP1 = reanalise.Abrasao.CPs.First(cp => cp.Ordem == 1).MI,
            Z28_MICP2 = reanalise.Abrasao.CPs.First(cp => cp.Ordem == 2).MI,
            Z28_MICP3 = reanalise.Abrasao.CPs.First(cp => cp.Ordem == 3).MI,
            Z28_MFCP1 = reanalise.Abrasao.CPs.First(cp => cp.Ordem == 1).MF,
            Z28_MFCP2 = reanalise.Abrasao.CPs.First(cp => cp.Ordem == 2).MF,
            Z28_MFCP3 = reanalise.Abrasao.CPs.First(cp => cp.Ordem == 3).MF
        };

        await dbConnection.ExecuteAsync(query, cpReanaliseDto);
    }

    private async Task CadastrarAbrasaoResultado(ResultadoCertificado resultadoCertificado)
    {
        var query = @"INSERT INTO Z26010
                        (Z26_FILIAL, Z26_CODRES, Z26_MICP1, Z26_MICP2, Z26_MICP3, 
                        Z26_MFCP1, Z26_MFCP2, Z26_MFCP3, R_E_C_N_O_)
                    VALUES
                        (@Z26_FILIAL, @Z26_CODRES, @Z26_MICP1, @Z26_MICP2, @Z26_MICP3, 
                        @Z26_MFCP1, @Z26_MFCP2, @Z26_MFCP3, (SELECT IDENT_CURRENT('Z26010')))";

        var cpResultadoDto = new CPResultadoDto
        {
            Z26_FILIAL = "0101",
            Z26_CODRES = resultadoCertificado.Codigo,
            Z26_MICP1 = resultadoCertificado.Abrasao.CPs.First(cp => cp.Ordem == 1).MI,
            Z26_MICP2 = resultadoCertificado.Abrasao.CPs.First(cp => cp.Ordem == 2).MI,
            Z26_MICP3 = resultadoCertificado.Abrasao.CPs.First(cp => cp.Ordem == 3).MI,
            Z26_MFCP1 = resultadoCertificado.Abrasao.CPs.First(cp => cp.Ordem == 1).MF,
            Z26_MFCP2 = resultadoCertificado.Abrasao.CPs.First(cp => cp.Ordem == 2).MF,
            Z26_MFCP3 = resultadoCertificado.Abrasao.CPs.First(cp => cp.Ordem == 3).MF
        };

        await dbConnection.ExecuteAsync(query, cpResultadoDto);
    }

    private async Task CadastrarAbrasaoItemPreTeste(ItemPreTeste itemPreTeste)
    {
        var query = @"INSERT INTO Z27010
                        (Z27_FILIAL, Z27_CODITM, Z27_MICP1, Z27_MICP2, Z27_MICP3, 
                        Z27_MFCP1, Z27_MFCP2, Z27_MFCP3, R_E_C_N_O_)
                    VALUES
                        (@Z27_FILIAL, @Z27_CODITM, @Z27_MICP1, @Z27_MICP2, @Z27_MICP3, 
                        @Z27_MFCP1, @Z27_MFCP2, @Z27_MFCP3, (SELECT IDENT_CURRENT('Z27010')))";

        var cpDto = new CPDto
        {
            Z27_FILIAL = "0101",
            Z27_CODITM = itemPreTeste.Codigo,
            Z27_MICP1 = itemPreTeste.Abrasao.CPs.First(cp => cp.Ordem == 1).MI,
            Z27_MICP2 = itemPreTeste.Abrasao.CPs.First(cp => cp.Ordem == 2).MI,
            Z27_MICP3 = itemPreTeste.Abrasao.CPs.First(cp => cp.Ordem == 3).MI,
            Z27_MFCP1 = itemPreTeste.Abrasao.CPs.First(cp => cp.Ordem == 1).MF,
            Z27_MFCP2 = itemPreTeste.Abrasao.CPs.First(cp => cp.Ordem == 2).MF,
            Z27_MFCP3 = itemPreTeste.Abrasao.CPs.First(cp => cp.Ordem == 3).MF
        };

        await dbConnection.ExecuteAsync(query, cpDto);
    }

    private async Task CadastrarTiposEspecificacoesResultado(ResultadoCertificado resultadoCertificado)
    {
        var query = @"DELETE FROM Z25010 WHERE Z25_CODRES = @Z25_CODRES";

        await dbConnection.ExecuteAsync(query, new { Z25_CODRES = resultadoCertificado.Codigo });

        query = @"INSERT INTO Z25010
                  (Z25_FILIAL, Z25_CODRES, Z25_CODESP, Z25_VALESP, R_E_C_N_O_)
                  VALUES
                  (@Z25_FILIAL, @Z25_CODRES, @Z25_CODESP, @Z25_VALESP, (SELECT IDENT_CURRENT('Z25010')));";

        var parameters =
            resultadoCertificado.TiposEspecificacoes
                .Select(t =>
                {
                    var parameters = new
                    {
                        Z25_FILIAL = "0101",
                        Z25_CODRES = resultadoCertificado.Codigo,
                        Z25_CODESP = t.Codigo,
                        Z25_VALESP = t.Valor
                    };

                    return parameters;
                }).ToList();

        if (resultadoCertificado.Abrasao is not null)
        {
            parameters.Add(new
            {
                Z25_FILIAL = "0101",
                Z25_CODRES = resultadoCertificado.Codigo,
                Z25_CODESP = "000005",
                Z25_VALESP = resultadoCertificado.Abrasao.Abrasividade
            });

            await CadastrarAbrasaoResultado(resultadoCertificado);
        }

        await dbConnection.ExecuteAsync(query, parameters);
    }

}