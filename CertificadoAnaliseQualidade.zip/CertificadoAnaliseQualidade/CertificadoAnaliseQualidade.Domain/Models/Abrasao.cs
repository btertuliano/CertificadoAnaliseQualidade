﻿namespace CertificadoAnaliseQualidade.Domain.Models;

public class Abrasao
{
    /// <summary>
    /// Lista de corpos de prova
    /// </summary>
    public IEnumerable<CP> CPs { get; set; }

    /// <summary>
    /// Desgaste do corpo de prova
    /// </summary>
    public decimal Abrasividade { get; set; }

}