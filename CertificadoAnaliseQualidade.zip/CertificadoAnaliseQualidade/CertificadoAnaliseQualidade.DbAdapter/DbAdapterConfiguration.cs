﻿namespace CertificadoAnaliseQualidade.DbAdapter;

public class DbAdapterConfiguration
{
    public string ConnectionString { get; set; }
}
