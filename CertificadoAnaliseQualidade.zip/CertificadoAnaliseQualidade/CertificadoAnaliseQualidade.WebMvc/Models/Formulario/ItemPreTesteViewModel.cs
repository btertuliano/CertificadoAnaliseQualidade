﻿using CertificadoAnaliseQualidade.Domain.Models;

namespace CertificadoAnaliseQualidade.WebMvc.Models.Formulario;

public class ItemPreTesteViewModel
{
    public ItemPreTeste ItemPreTeste { get; private set; }

    public ItemPreTesteViewModel(ItemPreTeste itemPreTeste)
    {
        ItemPreTeste = itemPreTeste;
    }
}