﻿namespace CertificadoAnaliseQualidade.Domain.Models;

public class Certificado
{
    /// <summary>
    /// Código do certificado
    /// </summary>
    public int Codigo { get; set; }

    /// <summary>
    /// Produto a ser testado
    /// </summary>
    public Produto Produto { get; set; }

    /// <summary>
    /// Data do cadastro do certificado
    /// </summary>
    public DateTime DataCadastro { get; set; }

    /// <summary>
    /// Situação do certificado
    /// </summary>
    public SituacaoCertificado SituacaoCertificado { get; set; }

    /// <summary>
    /// Lote de referência do produto
    /// </summary>
    public string LoteReferencia { get; set; }

    /// <summary>
    /// Observação do certificado
    /// </summary>
    public string ObservacaoCertificado { get; set; }

    /// <summary>
    /// Resultado média final das especificações
    /// </summary>
    public ResultadoMediaFinal ResultadoMediaFinal { get; set; }

    /// <summary>
    /// Lista os pré-testes do formulário
    /// </summary>
    public PreTeste PreTeste { get; set; }

    /// <summary>
    /// Lista dos resultados dos testes
    /// </summary>
    public IEnumerable<ResultadoCertificado> ResultadosCertificado { get; set; }

    /// <summary>
    /// Lista de alterações na fórmula feitas no M
    /// </summary>
    public IEnumerable<AlteracaoFormula> AlteracoesFormulas { get; set; }
}

public enum SituacaoCertificado
{
    Aberto = 1,
    EmAndamento = 2,
    Fechado = 3
}
