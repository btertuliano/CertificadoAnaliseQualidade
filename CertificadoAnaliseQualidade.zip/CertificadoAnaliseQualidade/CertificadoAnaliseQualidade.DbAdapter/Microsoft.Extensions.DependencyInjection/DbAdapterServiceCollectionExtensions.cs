﻿using CertificadoAnaliseQualidade.DbAdapter;
using CertificadoAnaliseQualidade.DbAdapter.Clients;
using CertificadoAnaliseQualidade.Domain.Adapters;
using System.Data;
using System.Data.SqlClient;

namespace Microsoft.Extensions.DependencyInjection;

public static class DbAdapterServiceCollectionExtensions
{
    public static IServiceCollection AddDbAdapter
        (this IServiceCollection services, DbAdapterConfiguration dbAdapterConfiguration)
    {
        if (services is null)
        {
            throw new ArgumentNullException(nameof(services));
        }

        if (dbAdapterConfiguration is null)
        {
            throw new ArgumentNullException(nameof(dbAdapterConfiguration));
        }

        services.AddSingleton<TipoEspecificacaoFactory>();

        services.AddScoped<IDbConnection>
            (c => new SqlConnection(dbAdapterConfiguration.ConnectionString));

        services.AddScoped<IDbAdapter, DbAdapter>();

        return services;
    }
}
