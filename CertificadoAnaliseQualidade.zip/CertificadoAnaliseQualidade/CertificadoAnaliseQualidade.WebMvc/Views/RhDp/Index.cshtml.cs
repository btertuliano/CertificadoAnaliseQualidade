using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CertificadoAnaliseQualidade.WebMvc.Views.Rh.Dp
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
