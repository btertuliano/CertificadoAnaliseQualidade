﻿using CertificadoAnaliseQualidade.Domain.Models.Abstracts;

namespace CertificadoAnaliseQualidade.Domain.Models;

public class ResultadoCertificado
{
    /// <summary>
    /// Amostra do resultado do certificado
    /// </summary>
    public int Codigo { get; set; }

    /// <summary>
    /// Código do certificado
    /// </summary>
    public int CertificadoCodigo { get; set; }

    /// <summary>
    /// Amostra do resultado do certificado
    /// </summary>
    public string Amostra { get; set; }

    /// <summary>
    /// Data e hora da injeção da amostra no resultado do certificado
    /// </summary>
    public DateTime DataInjecao { get; set; }

    /// <summary>
    /// Hora da análise final no resultado do certificado
    /// </summary>
    public TimeSpan HoraAnaliseFinal { get; set; }

    /// <summary>
    /// Analista responsável pelo fechamento do resultado
    /// </summary>
    public string AnalistaFechamento { get; set; }

    /// <summary>
    /// Quantidade de amostra no resultado do certificado
    /// </summary>
    public decimal Quantidade { get; set; }

    /// <summary>
    /// Analista de etiquetas responsável pela aprovação do resultado da amostra
    /// </summary>
    public string AnalistaEtiquetas { get; set; }

    /// <summary>
    /// Lista das análises visuais feita no resultado
    /// </summary>
    public AnaliseVisualResultado AnaliseVisualResultado { get; set; }

    /// <summary>
    /// Lista da reanálises feitas no resultado
    /// </summary>
    public Reanalise Reanalise { get; set; }

    /// <summary>
    /// Lista de especificações do produto
    /// </summary>
    public IEnumerable<TipoEspecificacao> TiposEspecificacoes { get; set; }

    /// <summary>
    /// Dados da abrasão do resultado
    /// </summary>
    public Abrasao Abrasao { get; set; }
}
