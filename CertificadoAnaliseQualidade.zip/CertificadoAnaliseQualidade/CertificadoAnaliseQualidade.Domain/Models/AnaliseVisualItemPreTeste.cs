﻿namespace CertificadoAnaliseQualidade.Domain.Models;

public class AnaliseVisualItemPreTeste
{
    /// <summary>
    /// Código da análise visual
    /// </summary>
    public int Codigo { get; set; }

    /// <summary>
    /// Código do item do pré-teste
    /// </summary>
    public int ItemPreTesteCodigo { get; set; }

    /// <summary>
    /// Determina o tamanho e suas partículas
    /// </summary>
    public AnaliseVisualItemPreTesteTipo Granulometria { get; set; }

    /// <summary>
    /// Plastificação da amostra
    /// </summary>
    public AnaliseVisualItemPreTesteTipo Plastificacao { get; set; }

    /// <summary>
    /// Cor da amostra
    /// </summary>
    public AnaliseVisualItemPreTesteTipo Cor { get; set; }

    /// <summary>
    /// Manchas brancas na formação da amostra
    /// </summary>
    public AnaliseVisualItemPreTesteTipo MaDispersaoSilica { get; set; }

    /// <summary>
    /// Extrusora solta uma fita bem fina para teste
    /// </summary>
    public AnaliseVisualItemPreTesteTipo FitaMonorosca { get; set; }

    /// <summary>
    /// Gases da amostra
    /// </summary>
    public AnaliseVisualItemPreTesteTipo Gases { get; set; }

    /// <summary>
    /// Matéria prima não derrete de forma correta
    /// </summary>
    public AnaliseVisualItemPreTesteTipo Olhinhos { get; set; }

    /// <summary>
    /// Analista que executou a análise visual
    /// </summary>
    public string Analista { get; set; }

    /// <summary>
    /// Observação da análise visual
    /// </summary>
    public string Observacao { get; set; }

}

public enum AnaliseVisualItemPreTesteTipo
{
    Sim = 1,
    Nao = 0,
    Na = 2
}

