﻿using CertificadoAnaliseQualidade.Domain.Models;

namespace CertificadoAnaliseQualidade.WebMvc.Models.Formulario;

public class AbrasaoItemPreTesteLeituraViewModel
{
    public Abrasao AbrasaoItemPreTeste { get; private set; }

    public AbrasaoItemPreTesteLeituraViewModel(Abrasao abrasao)
    {
        AbrasaoItemPreTeste = abrasao;
    }

    public CP ObterCp(int ordem)
    {
        return AbrasaoItemPreTeste.CPs.SingleOrDefault(c => c.Ordem == ordem);
    }
}
