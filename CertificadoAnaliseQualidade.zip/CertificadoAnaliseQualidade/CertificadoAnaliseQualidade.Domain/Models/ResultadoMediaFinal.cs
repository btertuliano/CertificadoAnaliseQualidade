﻿using CertificadoAnaliseQualidade.Domain.Models.Abstracts;

namespace CertificadoAnaliseQualidade.Domain.Models;

public class ResultadoMediaFinal
{
    /// <summary>
    /// Lista de tipo especificações
    /// </summary>
    private IList<TipoEspecificacao> tiposEspecificacoes;

    /// <summary>
    /// Resultado dos tipos de especificações
    /// </summary>
    public ResultadoMediaFinal()
    {
        tiposEspecificacoes = new List<TipoEspecificacao>();

        //- DENSIDADE(000006): Média Densidade Resultado
        //- DUREZA(000001): Média dureza hora do resultado
        //- FLUIDEZ(000003): (VALOR * Fator fixo) { Média Índice de Fluidez(g/ 10 min) da Fluidez}
        //- UMIDADE(000007): Média umidade do resultado
        //- ABRASÃO(000005): (((MI – MF) * Fator fixo) / (Abrasividade * Densidade)) { Média da média do calculo abrasão}
        //- DENSIDADE APARENTE(000002): Média densidade aparente do resultado
        //- EXPANSÃO(000004): Média expansão do resultado
    }

    /// <summary>
    /// Adicionar tipo especificação
    /// </summary>
    /// <param name="tipoEspecificacao">Adicionar tipos especificações</param>
    public void Adicionar(TipoEspecificacao tipoEspecificacao)
    {
        tiposEspecificacoes.Add(tipoEspecificacao);
    }
}
