﻿using CertificadoAnaliseQualidade.Domain.Models;

namespace CertificadoAnaliseQualidade.WebMvc.Models.Formulario;

public class AbrasaoResultadoLeituraViewModel
{
    public Abrasao AbrasaoResultado { get; private set; }

    public AbrasaoResultadoLeituraViewModel(Abrasao abrasao)
    {
        AbrasaoResultado = abrasao;
    }

    public CP ObterCp(int ordem)
    {
        return AbrasaoResultado.CPs.SingleOrDefault(c => c.Ordem == ordem);
    }
}
