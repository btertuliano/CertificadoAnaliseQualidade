﻿using CertificadoAnaliseQualidade.Domain.Models;

namespace CertificadoAnaliseQualidade.WebMvc.Models.Formulario;

public class ResultadoViewModel
{
    public ResultadoCertificado ResultadoCertificado { get; private set; }

    public ResultadoViewModel(ResultadoCertificado resultadoCertificado)
    {
        ResultadoCertificado = resultadoCertificado;
    }
}
