﻿namespace CertificadoAnaliseQualidade.Domain.Models;

public class Fluidez
{
    /// <summary>
    /// Amostra de qualidade do produto
    /// </summary>
    public string Amostra { get; set; }

    /// <summary>
    /// Valor médio da fluidez
    /// </summary>
    public decimal ValorMedio { get; set; }

    /// <summary>
    /// Avaliação da massa molecular
    /// </summary>
    public decimal IndiceFluidez { get; set; }
}
