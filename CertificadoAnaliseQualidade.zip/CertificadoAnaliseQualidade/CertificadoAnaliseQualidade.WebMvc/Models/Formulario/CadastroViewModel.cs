﻿using CertificadoAnaliseQualidade.Domain.Models;
using CertificadoAnaliseQualidade.Domain.Models.Abstracts;

namespace CertificadoAnaliseQualidade.WebMvc.Models.Formulario;

public class CadastroViewModel
{
    public Certificado Certificado { get; private set; }
    public Produto Produto { get; private set; }

    public IEnumerable<ViewModelRadio> ConferenciasCargaRadios { get; set; }
    public IEnumerable<ViewModelRadio> ConferenciasOleosRadios { get; set; }
    public IEnumerable<ViewModelRadio> GranulometriasAnaliseVisualItemPreTesteRadios { get; set; }
    public IEnumerable<ViewModelRadio> PlastificacaoAnaliseVisualItemPreTesteRadios { get; set; }
    public IEnumerable<ViewModelRadio> CorAnaliseVisualItemPreTesteRadios { get; set; }
    public IEnumerable<ViewModelRadio> MaDispSilicaAnaliseVisualItemPreTesteRadios { get; set; }
    public IEnumerable<ViewModelRadio> OlhinhosAnaliseVisualItemPreTesteRadios { get; set; }
    public IEnumerable<ViewModelRadio> FitaMonoroscaAnaliseVisualItemPreTesteRadios { get; set; }
    public IEnumerable<ViewModelRadio> GasesAnaliseVisualItemPreTesteRadios { get; set; }

    public IEnumerable<ViewModelRadio> GranulometriaAnaliseVisualResultadoRadios { get; set; }
    public IEnumerable<ViewModelRadio> PlastificacaoAnaliseVisualResultadoRadios { get; set; }
    public IEnumerable<ViewModelRadio> CorAnaliseVisualResultadoRadios { get; set; }
    public IEnumerable<ViewModelRadio> MaDispSilicaAnaliseVisualResultadoRadios { get; set; }
    public IEnumerable<ViewModelRadio> OlhinhosAnaliseVisualResultadoRadios { get; set; }
    public IEnumerable<ViewModelRadio> FitaMonoroscaAnaliseVisualResultadoRadios { get; set; }
    public IEnumerable<ViewModelRadio> GasesAnaliseVisualResultadoRadios { get; set; }

    public CadastroViewModel(Certificado certificado, Produto produto)
    {
        Certificado = certificado;
        Produto = produto;

        ConferenciasCargaRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "conferenciaCargaPreTesteSim",
                Nome = "conferenciaCargaPreTeste",
                Descricao = "Sim",
                Checked = certificado.PreTeste.ConferenciaCarga ? true : false
            },
            new ViewModelRadio
            {
                Identificador = "conferenciaCargaPreTesteNao",
                Nome = "conferenciaCargaPreTeste",
                Descricao = "Não",
                Checked = certificado.PreTeste.ConferenciaCarga ? false : true
            }
        };

        ConferenciasOleosRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "conferenciaOleoPreTesteSim",
                Nome = "conferenciaOleoPreTeste",
                Descricao = "Sim",
                Checked = certificado.PreTeste.ConferenciaOleo ? true : false
            },
            new ViewModelRadio
            {
                Identificador = "conferenciaOleoPreTesteNao",
                Nome = "conferenciaOleoPreTeste",
                Descricao = "Não",
                Checked = certificado.PreTeste.ConferenciaOleo ? false : true
            }
        };

        GranulometriasAnaliseVisualItemPreTesteRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "granulometriaAnaliseVisualPreTesteSim",
                Nome = "granulometriaAnaliseVisualPreTesteRadios",
                Descricao = "Sim",
                Valor = AnaliseVisualItemPreTesteTipo.Sim.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "granulometriaAnaliseVisualPreTesteNao",
                Nome = "granulometriaAnaliseVisualPreTesteRadios",
                Descricao = "Não",
                Valor = AnaliseVisualItemPreTesteTipo.Nao.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "granulometriaAnaliseVisualPreTesteNa",
                Nome = "granulometriaAnaliseVisualPreTesteRadios",
                Descricao = "N/A",
                Valor = AnaliseVisualItemPreTesteTipo.Na.ToString(),
                Checked = false
            }
        };

        PlastificacaoAnaliseVisualItemPreTesteRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "plastificacaoAnaliseVisualItemPreTesteRadiosSim",
                Nome = "plastificacaoAnaliseVisualItemPreTesteRadios",
                Descricao = "Sim",
                Valor = AnaliseVisualItemPreTesteTipo.Sim.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "plastificacaoAnaliseVisualItemPreTesteRadiosNao",
                Nome = "plastificacaoAnaliseVisualItemPreTesteRadios",
                Descricao = "Não",
                Valor = AnaliseVisualItemPreTesteTipo.Nao.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "plastificacaoAnaliseVisualItemPreTesteRadiosNa",
                Nome = "plastificacaoAnaliseVisualItemPreTesteRadios",
                Descricao = "N/A",
                Valor = AnaliseVisualItemPreTesteTipo.Na.ToString(),
                Checked = false
            }
        };

        CorAnaliseVisualItemPreTesteRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "corAnaliseVisualItemPreTesteRadiosSim",
                Nome = "corAnaliseVisualItemPreTesteRadios",
                Descricao = "Sim",
                Valor = AnaliseVisualItemPreTesteTipo.Sim.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "corAnaliseVisualItemPreTesteRadiosNao",
                Nome = "corAnaliseVisualItemPreTesteRadios",
                Descricao = "Não",
                Valor = AnaliseVisualItemPreTesteTipo.Nao.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "corAnaliseVisualItemPreTesteRadiosNa",
                Nome = "corAnaliseVisualItemPreTesteRadios",
                Descricao = "N/A",
                Valor = AnaliseVisualItemPreTesteTipo.Na.ToString(),
                Checked = false
            }
        };

        MaDispSilicaAnaliseVisualItemPreTesteRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "maDispSilicaAnaliseVisualItemPreTesteRadiosSim",
                Nome = "maDispSilicaAnaliseVisualItemPreTesteRadios",
                Descricao = "Sim",
                Valor = AnaliseVisualItemPreTesteTipo.Sim.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "maDispSilicaAnaliseVisualItemPreTesteRadiosNao",
                Nome = "maDispSilicaAnaliseVisualItemPreTesteRadios",
                Descricao = "Não",
                Valor = AnaliseVisualItemPreTesteTipo.Nao.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "maDispSilicaAnaliseVisualItemPreTesteRadiosNa",
                Nome = "maDispSilicaAnaliseVisualItemPreTesteRadios",
                Descricao = "N/A",
                Valor = AnaliseVisualItemPreTesteTipo.Na.ToString(),
                Checked = false
            }
        };

        OlhinhosAnaliseVisualItemPreTesteRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "olhinhosAnaliseVisualItemPreTesteRadiosSim",
                Nome = "olhinhosAnaliseVisualItemPreTesteRadios",
                Descricao = "Sim",
                Valor = AnaliseVisualItemPreTesteTipo.Sim.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "olhinhosAnaliseVisualItemPreTesteRadiosNao",
                Nome = "olhinhosAnaliseVisualItemPreTesteRadios",
                Descricao = "Não",
                Valor = AnaliseVisualItemPreTesteTipo.Nao.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "olhinhosAnaliseVisualItemPreTesteRadiosNa",
                Nome = "olhinhosAnaliseVisualItemPreTesteRadios",
                Descricao = "N/A",
                Valor = AnaliseVisualItemPreTesteTipo.Na.ToString(),
                Checked = false
            }
        };

        FitaMonoroscaAnaliseVisualItemPreTesteRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "fitaMonoroscaAnaliseVisualItemPreTesteRadiosSim",
                Nome = "fitaMonoroscaAnaliseVisualItemPreTesteRadios",
                Descricao = "Sim",
                Valor = AnaliseVisualItemPreTesteTipo.Sim.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "fitaMonoroscaAnaliseVisualItemPreTesteRadiosNao",
                Nome = "fitaMonoroscaAnaliseVisualItemPreTesteRadios",
                Descricao = "Não",
                Valor = AnaliseVisualItemPreTesteTipo.Nao.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "fitaMonoroscaAnaliseVisualItemPreTesteRadiosNa",
                Nome = "fitaMonoroscaAnaliseVisualItemPreTesteRadios",
                Descricao = "N/A",
                Valor = AnaliseVisualItemPreTesteTipo.Na.ToString(),
                Checked = false
            }
        };

        GasesAnaliseVisualItemPreTesteRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "gasesAnaliseVisualItemPreTesteRadiosSim",
                Nome = "gasesAnaliseVisualItemPreTesteRadios",
                Descricao = "Sim",
                Valor = AnaliseVisualItemPreTesteTipo.Sim.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "gasesAnaliseVisualItemPreTesteRadiosNao",
                Nome = "gasesAnaliseVisualItemPreTesteRadios",
                Descricao = "Não",
                Valor = AnaliseVisualItemPreTesteTipo.Nao.ToString(),
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "gasesAnaliseVisualItemPreTesteRadiosNa",
                Nome = "gasesAnaliseVisualItemPreTesteRadios",
                Descricao = "N/A",
                Valor = AnaliseVisualItemPreTesteTipo.Na.ToString(),
                Checked = false
            }
        };


        GranulometriaAnaliseVisualResultadoRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "granulometriaAnaliseVisualResultadoSim",
                Nome = "granulometriaAnaliseVisualResultadoRadios",
                Descricao = "Sim",
                Valor = "1",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "granulometriaAnaliseVisualResultadoNao",
                Nome = "granulometriaAnaliseVisualResultadoRadios",
                Descricao = "Não",
                Valor = "0",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "granulometriaAnaliseVisualResultadoNa",
                Nome = "granulometriaAnaliseVisualResultadoRadios",
                Descricao = "N/A",
                Valor = "2",
                Checked = false
            }
        };

        PlastificacaoAnaliseVisualResultadoRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "plastificacaoAnaliseVisualResultadoRadiosSim",
                Nome = "plastificacaoAnaliseVisualResultadoRadios",
                Descricao = "Sim",
                Valor = "1",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "plastificacaoAnaliseVisualResultadoRadiosNao",
                Nome = "plastificacaoAnaliseVisualResultadoRadios",
                Descricao = "Não",
                Valor = "0",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "plastificacaoAnaliseVisualResultadoRadiosNa",
                Nome = "plastificacaoAnaliseVisualResultadoRadios",
                Descricao = "N/A",
                Valor = "2",
                Checked = false
            }
        };

        CorAnaliseVisualResultadoRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "corAnaliseVisualResultadoRadiosSim",
                Nome = "corAnaliseVisualResultadoRadios",
                Descricao = "Sim",
                Valor = "1",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "corAnaliseVisualResultadoRadiosNao",
                Nome = "corAnaliseVisualResultadoRadios",
                Descricao = "Não",
                Valor = "0",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "corAnaliseVisualResultadoRadiosNa",
                Nome = "corAnaliseVisualResultadoRadios",
                Descricao = "N/A",
                Valor = "2",
                Checked = false
            }
        };

        MaDispSilicaAnaliseVisualResultadoRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "maDispSilicaAnaliseVisualResultadoRadiosSim",
                Nome = "maDispSilicaAnaliseVisualResultadoRadios",
                Descricao = "Sim",
                Valor = "1",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "maDispSilicaAnaliseVisualResultadoRadiosNao",
                Nome = "maDispSilicaAnaliseVisualResultadoRadios",
                Descricao = "Não",
                Valor = "0",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "maDispSilicaAnaliseVisualResultadoRadiosNa",
                Nome = "maDispSilicaAnaliseVisualResultadoRadios",
                Descricao = "N/A",
                Valor = "2",
                Checked = false
            }
        };

        OlhinhosAnaliseVisualResultadoRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "olhinhosAnaliseVisualResultadoRadiosSim",
                Nome = "olhinhosAnaliseVisualResultadoRadios",
                Descricao = "Sim",
                Valor = "1",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "olhinhosAnaliseVisualResultadoRadiosNao",
                Nome = "olhinhosAnaliseVisualResultadoRadios",
                Descricao = "Não",
                Valor = "0",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "olhinhosAnaliseVisualResultadoRadiosNa",
                Nome = "olhinhosAnaliseVisualResultadoRadios",
                Descricao = "N/A",
                Valor = "2",
                Checked = false
            }
        };

        FitaMonoroscaAnaliseVisualResultadoRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "fitaMonoroscaAnaliseVisualResultadoRadiosSim",
                Nome = "fitaMonoroscaAnaliseVisualResultadoRadios",
                Descricao = "Sim",
                Valor = "1",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "fitaMonoroscaAnaliseVisualResultadoRadiosNao",
                Nome = "fitaMonoroscaAnaliseVisualResultadoRadios",
                Descricao = "Não",
                Valor = "0",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "fitaMonoroscaAnaliseVisualResultadoRadiosNa",
                Nome = "fitaMonoroscaAnaliseVisualResultadoRadios",
                Descricao = "N/A",
                Valor = "2",
                Checked = false
            }
        };

        GasesAnaliseVisualResultadoRadios = new List<ViewModelRadio>
        {
            new ViewModelRadio
            {
                Identificador = "gasesAnaliseVisualResultadoRadiosSim",
                Nome = "gasesAnaliseVisualResultadoRadios",
                Descricao = "Sim",
                Valor = "1",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "gasesAnaliseVisualResultadoRadiosNao",
                Nome = "gasesAnaliseVisualResultadoRadios",
                Descricao = "Não",
                Valor = "0",
                Checked = false
            },
            new ViewModelRadio
            {
                Identificador = "gasesAnaliseVisualResultadoRadiosNa",
                Nome = "gasesAnaliseVisualResultadoRadios",
                Descricao = "N/A",
                Valor = "2",
                Checked = false
            }
        };
    }

    public IEnumerable<TipoEspecificacao> ObterTiposEspecificacoesComDurezasInicialFinal()
    {
        var durezaTipoEspecificacao = Produto.TiposEspecificacoes.FirstOrDefault(t => t.Codigo == "000001");

        if (durezaTipoEspecificacao is null)
        {
            return Produto.TiposEspecificacoes;
        }

        var tiposEspecificacoesSemDureza = Produto.TiposEspecificacoes.Where(t => t.Codigo != "000001");
        var tiposEspecificacoesDurezasInicialFinal = new List<TipoEspecificacao>
        {
            new DurezaTipoEspecificacao
            {
                Codigo = durezaTipoEspecificacao.Codigo,
                Descricao = "Dureza inicial"
            },
            new DurezaTipoEspecificacao
            {
                Codigo = durezaTipoEspecificacao.Codigo,
                Descricao = "Dureza final"
            }
        };

        var tiposEspecificacoes = tiposEspecificacoesSemDureza.Concat(tiposEspecificacoesDurezasInicialFinal);

        return tiposEspecificacoes;
    }

    public bool ExibirItensPreTeste()
    {
        return Certificado.PreTeste.Itens.Any();
    }

    public bool ExibirResultado()
    {
        return Certificado.ResultadosCertificado.Any();
    }

    public bool ExibirAlteracoesFormulas()
    {
        return Certificado.AlteracoesFormulas.Any();
    }

    public class ViewModelRadio
    {
        public string Identificador { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public string Valor { get; set; }
        public bool Checked { get; set; }

    }
}