﻿using CertificadoAnaliseQualidade.Domain.Models;

namespace CertificadoAnaliseQualidade.Domain.Services;

public interface IProdutosService
{
    /// <summary>
    /// Obtém todos os produtos
    /// </summary>
    /// <returns>Lista de produtos</returns>
    Task<IEnumerable<Produto>> ObterProdutosAsync();

    /// <summary>
    /// Obtém produto pelo código
    /// </summary>
    /// <returns>Dados do produto</returns>
    Task<Produto> ObterProdutoAsync(string codigo, string lote);
}
