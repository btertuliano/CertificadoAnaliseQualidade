﻿using CertificadoAnaliseQualidade.Domain.Adapters;
using CertificadoAnaliseQualidade.Domain.Models;
using System.Data;
using Dapper;
using CertificadoAnaliseQualidade.DbAdapter.Clients;
using AutoMapper;

namespace CertificadoAnaliseQualidade.DbAdapter;

public partial class DbAdapter : IDbAdapter
{
    private readonly IDbConnection dbConnection;
    private readonly IMapper mapper;
    private readonly TipoEspecificacaoFactory factory;

    public DbAdapter(IDbConnection dbConnection, IMapper mapper, TipoEspecificacaoFactory factory)
    {
        this.dbConnection = dbConnection
            ?? throw new ArgumentNullException(nameof(dbConnection));

        this.mapper = mapper
            ?? throw new ArgumentNullException(nameof(mapper));

        this.factory = factory
            ?? throw new ArgumentNullException(nameof(factory));
    }

    public async Task AtualizarCertificadoAsync(Certificado certificado)
    {
        var query = @"UPDATE Z16010 
		                SET Z16_LOTREF = @Z16_LOTREF, 
                        Z16_OBS = @Z16_OBS 
	                WHERE Z16_CODSEQ = @Z16_CODSEQ";

        var certificadoDto = mapper.Map<CertificadoDto>(certificado);

        await dbConnection.ExecuteAsync(query, certificadoDto);
    }

    public async Task AtualizarPreTesteAsync(PreTeste preTeste)
    {
        var query = @"UPDATE Z17010 SET
                        Z17_CONFCA = @Z17_CONFCA,
                        Z17_ACONCA = @Z17_ACONCA,
                        Z17_CONFOL = @Z17_CONFOL,
                        Z17_ACONOL = @Z17_ACONOL
                      WHERE Z17_CODPTE = @Z17_CODPTE";

        var preTesteDto = mapper.Map<PreTesteDto>(preTeste);

        await dbConnection.ExecuteAsync(query, preTesteDto);
    }

    public async Task<Certificado> CadastrarCertificadoAsync(Certificado certificado)
    {
        var query = @"INSERT INTO Z16010
                           (Z16_FILIAL, Z16_LOTE, Z16_SITCER, R_E_C_N_O_, Z16_DTCAD)
                     OUTPUT INSERTED.[Z16_CODSEQ]
                     VALUES
                           (@Z16_FILIAL, @Z16_LOTE, @Z16_SITCER, 
                           (SELECT IDENT_CURRENT('Z16010')), @Z16_DTCAD)";

        var certificadoDto = mapper.Map<CertificadoDto>(certificado);

        certificado.Codigo = await dbConnection.QuerySingleOrDefaultAsync<int>(query, certificadoDto);

        return certificado;
    }

    public async Task<AlteracaoFormula> CadastrarAlteracaoFormulaAsync(AlteracaoFormula alteracaoFormula)
    {
        var query = @"INSERT INTO Z19010
                           (Z19_FILIAL, Z19_CODSEQ, Z19_DTALT, Z19_SUBLOT, 
                            Z19_ANALIS, Z19_MALT, Z19_DESCAL, R_E_C_N_O_)
                     OUTPUT INSERTED.[Z19_CODALT]
                     VALUES
                           (@Z19_FILIAL, @Z19_CODSEQ, @Z19_DTALT, @Z19_SUBLOT, 
                            @Z19_ANALIS, @Z19_MALT, @Z19_DESCAL, (SELECT IDENT_CURRENT('Z19010')))";

        var alteracaoFormulaDto = mapper.Map<AlteracaoFormulaDto>(alteracaoFormula);

        alteracaoFormula.Codigo = await dbConnection.QuerySingleOrDefaultAsync<int>(query, alteracaoFormulaDto);

        return alteracaoFormula;
    }

    public async Task<ItemPreTeste> CadastrarItemPreTeste(ItemPreTeste itemPreTeste)
    {
        var query = @"INSERT INTO Z22010
                           (Z22_FILIAL, Z22_CODPTE, Z22_DTHINJ, Z22_HTESTE, Z22_HRET, Z22_AANALT, Z22_AMOLI, Z22_OBS, R_E_C_N_O_)
                     OUTPUT INSERTED.[Z22_CODITM]
                     VALUES
                           (@Z22_FILIAL, @Z22_CODPTE, @Z22_DTHINJ, @Z22_HTESTE, @Z22_HRET, @Z22_AANALT, @Z22_AMOLI, @Z22_OBS,
                           (SELECT IDENT_CURRENT('Z22010')))";

        var itemPreTesteDto = mapper.Map<ItemPreTesteDto>(itemPreTeste);

        itemPreTeste.Codigo = await dbConnection.QuerySingleOrDefaultAsync<int>(query, itemPreTesteDto);

        itemPreTeste.AnaliseVisualItemPreTeste.ItemPreTesteCodigo = itemPreTeste.Codigo;

        await CadastrarTiposEspecificacoesItemPreTeste(itemPreTeste);
        await CadastrarAnaliseVisualItemPreTeste(itemPreTeste);

        return itemPreTeste;
    }

    public async Task<ResultadoCertificado> CadastrarResultado(ResultadoCertificado resultadoCertificado)
    {
        var query = @"INSERT INTO Z18010
                           (Z18_FILIAL, Z18_CODSEQ, Z18_CODAM, Z18_DTHINJ, Z18_HAFIN, Z18_AFECH, Z18_QTD, Z18_AETQ, R_E_C_N_O_)
                     OUTPUT INSERTED.[Z18_CODRES]
                     VALUES
                           (@Z18_FILIAL, @Z18_CODSEQ, @Z18_CODAM, @Z18_DTHINJ, @Z18_HAFIN, @Z18_AFECH, @Z18_QTD, @Z18_AETQ, 
                            (SELECT IDENT_CURRENT('Z18010')))";

        var resultadoDto = mapper.Map<ResultadoDto>(resultadoCertificado);

        resultadoCertificado.Codigo = await dbConnection.QuerySingleOrDefaultAsync<int>(query, resultadoDto);

        resultadoCertificado.AnaliseVisualResultado.ResultadoCodigo = resultadoCertificado.Codigo;

        await CadastrarTiposEspecificacoesResultado(resultadoCertificado);
        await CadastrarAnaliseVisualResultado(resultadoCertificado);

        return resultadoCertificado;
    }


    public async Task<PreTeste> CadastrarPreTeste(Certificado certificado)
    {
        var query = @"INSERT INTO Z17010
                      (Z17_FILIAL, Z17_CODSEQ, Z17_CONFCA, Z17_ACONCA, Z17_CONFOL, Z17_ACONOL, D_E_L_E_T_, R_E_C_N_O_)
                      OUTPUT INSERTED.[Z17_CODPTE]
                      VALUES
                      (@Z17_FILIAL, @Z17_CODSEQ, @Z17_CONFCA, @Z17_ACONCA, @Z17_CONFOL, @Z17_ACONOL, '', (SELECT IDENT_CURRENT('Z17010')))";

        var pretesteDto = mapper.Map<PreTesteDto>(certificado.PreTeste);
        var parameters = new DynamicParameters(pretesteDto);

        parameters.Add("Z17_CODSEQ", certificado.Codigo);

        certificado.PreTeste.Codigo = await dbConnection.QuerySingleOrDefaultAsync<int>(query, parameters);

        return certificado.PreTeste;
    }

    public async Task<Certificado> ObterCertificadoAsync(int codigo)
    {
        var query = @"SELECT DISTINCT
	                    certificados.Z16_CODSEQ,
	                    certificados.Z16_SITCER,
	                    certificados.Z16_DTCAD,
                        certificados.Z16_LOTREF,
                        certificados.Z16_OBS,
	                    produto.B1_DESC,
                        produto.B1_COD,
	                    certificados.Z16_LOTE AS B8_LOTECTL,
                        MIN(lote.B8_DFABRIC) AS B8_DFABRIC,
                        preTeste.Z17_CODPTE,
                        preTeste.Z17_CONFCA,
                        preTeste.Z17_ACONCA,
                        preTeste.Z17_CONFOL,
                        preTeste.Z17_ACONOL
                    FROM Z16010 certificados
	                    INNER JOIN SB8010 AS lote ON lote.D_E_L_E_T_ = ''
		                    AND certificados.Z16_LOTE = lote.B8_LOTECTL
						INNER JOIN SB1010 produto ON produto.D_E_L_E_T_ = ''
                            AND lote.B8_PRODUTO = produto.B1_COD
                        INNER JOIN Z17010 AS preTeste ON preTeste.D_E_L_E_T_ = ''
                            AND certificados.Z16_CODSEQ = preTeste.Z17_CODSEQ
                    WHERE certificados.D_E_L_E_T_ = '' AND Z16_CODSEQ = @Z16_CODSEQ
                    GROUP BY certificados.Z16_CODSEQ,
                        certificados.Z16_SITCER,
                        certificados.Z16_DTCAD,
                        certificados.Z16_LOTREF,
                        certificados.Z16_OBS,
                        produto.B1_DESC,
                        produto.B1_COD,
                        certificados.Z16_LOTE,
                        preTeste.Z17_CODPTE,
                        preTeste.Z17_CODPTE,
                        preTeste.Z17_CONFCA,
                        preTeste.Z17_ACONCA,
                        preTeste.Z17_CONFOL,
                        preTeste.Z17_ACONOL";

        var certificados = await dbConnection.QueryAsync<CertificadoDto, ProdutoDto, PreTesteDto, Certificado>(query,
            (certificadoDto, produtoDto, preTesteDto) =>
            {
                certificadoDto.Produto = produtoDto;
                certificadoDto.PreTeste = preTesteDto;

                return mapper.Map<Certificado>(certificadoDto);
            }
            , splitOn: "B1_DESC,Z17_CODPTE",
            param: new { Z16_CODSEQ = codigo });

        var certificado = certificados.FirstOrDefault();

        if (certificado is not null)
        {
            certificado.PreTeste.Itens =
                await ObterItensPreTesteAsync(certificado.PreTeste.Codigo);

            certificado.ResultadosCertificado =
                await ObterResultadoCertificadoAsync(certificado.Codigo);

            certificado.AlteracoesFormulas =
                await ObterAlteracoesFormulasAsync(certificado.Codigo);
        }

        return certificados.FirstOrDefault();
    }

    public async Task<Certificado> ObterCertificadoPorLoteAsync(string lote)
    {
        var query = @"SELECT 
	                    certificados.Z16_CODSEQ,
	                    certificados.Z16_SITCER,
	                    certificados.Z16_DTCAD,
	                    produto.B1_DESC,
	                    lote.B8_LOTECTL,
	                    MIN(lote.B8_DFABRIC) AS B8_DFABRIC,
                        preTeste.Z17_CODPTE,
                        preTeste.Z17_CONFCA,
                        preTeste.Z17_ACONCA,
                        preTeste.Z17_CONFOL,
                        preTeste.Z17_ACONOL
                    FROM SB8010 AS lote
						INNER JOIN SB1010 produto ON produto.D_E_L_E_T_ = ''
                            AND lote.B8_PRODUTO = produto.B1_COD
						LEFT JOIN Z16010 certificados ON certificados.D_E_L_E_T_ = ''
							AND lote.B8_LOTECTL = certificados.Z16_LOTE
                        LEFT JOIN Z17010 AS preTeste ON preTeste.D_E_L_E_T_ = ''
                            AND certificados.Z16_CODSEQ = preTeste.Z17_CODSEQ
                    WHERE lote.D_E_L_E_T_ = '' AND lote.B8_LOTECTL = @B8_LOTECTL
                    GROUP BY 
						certificados.Z16_CODSEQ,
	                    certificados.Z16_SITCER,
	                    certificados.Z16_DTCAD,
	                    produto.B1_DESC,
	                    lote.B8_LOTECTL,
                        preTeste.Z17_CODPTE,
                        preTeste.Z17_CONFCA,
                        preTeste.Z17_ACONCA,
                        preTeste.Z17_CONFOL,
                        preTeste.Z17_ACONOL";

        var certificados = await dbConnection.QueryAsync<CertificadoDto, ProdutoDto, PreTesteDto, Certificado>(query,
            (certificadoDto, produtoDto, preTesteDto) =>
            {
                certificadoDto.Produto = produtoDto;
                certificadoDto.PreTeste = preTesteDto;

                return mapper.Map<Certificado>(certificadoDto);
            }
            , splitOn: "B1_DESC,B8_DFABRIC",
            param: new { B8_LOTECTL = lote });

        return certificados.FirstOrDefault();
    }

    public async Task<Produto> ObterProdutoAsync(string codigo, string lote)
    {
        var query = @"SELECT 
		                B1_COD,
		                B1_DESC,
						lote.B8_LOTECTL,
						MIN(lote.B8_DFABRIC) AS B8_DFABRIC,
	                    Z11_DESC,
						Z11_COD,
	                    Z12_VALOR,
	                    Z12_TOLER
                    FROM SB1010 produto
						INNER JOIN SB8010 lote ON lote.D_E_L_E_T_ = ''
							AND produto.B1_COD = lote.B8_PRODUTO
	                    INNER JOIN Z12010 especProduto ON especProduto.D_E_L_E_T_ = ''
		                    AND B1_COD = especProduto.Z12_PROD
	                    INNER JOIN Z11010 especificacao ON especificacao.D_E_L_E_T_ = ''
		                    AND especProduto.Z12_ESPEC = especificacao.Z11_COD
                    WHERE produto.D_E_L_E_T_ = '' AND B1_COD = @B1_COD AND lote.B8_LOTECTL = @B8_LOTECTL
                    GROUP BY
						B1_COD,
		                B1_DESC,
						lote.B8_LOTECTL,
	                    Z11_DESC,
						Z11_COD,
	                    Z12_VALOR,
	                    Z12_TOLER";

        var produtosDto = await dbConnection.QueryAsync<ProdutoDto, TipoEspecificacaoDto, ProdutoDto>(query,
            (produtoDto, tipoEspecificacaoDto) =>
            {
                produtoDto.TipoEspecificacao = tipoEspecificacaoDto;
                return produtoDto;
            }
            , splitOn: "Z11_DESC",
            param: new { B1_COD = codigo, B8_LOTECTL = lote });

        var produto = mapper.Map<Produto>(produtosDto.FirstOrDefault());

        produto.TiposEspecificacoes = produtosDto
            .Select(pDto => factory.Create(mapper, pDto.TipoEspecificacao))
            .ToList();

        return produto;
    }

    public async Task<IEnumerable<Produto>> ObterProdutosAsync()
    {
        var query = @"SELECT DISTINCT
	                    B1_COD,
	                    B1_DESC,
	                    lote.B8_LOTECTL,
	                    lote.B8_DFABRIC
                    FROM SB8010 lote
	                    INNER JOIN SB1010 produto ON produto.D_E_L_E_T_ = ''
		                    AND lote.B8_PRODUTO = produto.B1_COD
                        INNER JOIN Z12010 especProduto ON especProduto.D_E_L_E_T_ = ''
		                    AND B1_COD = especProduto.Z12_PROD
	                    INNER JOIN Z11010 especificacao ON especificacao.D_E_L_E_T_ = ''
		                    AND especProduto.Z12_ESPEC = especificacao.Z11_COD
                    WHERE lote.D_E_L_E_T_ = ''";

        var produtosDto = await dbConnection.QueryAsync<ProdutoDto>(query);

        var produtos = mapper.Map<IEnumerable<Produto>>(produtosDto);

        return produtos;
    }

    public async Task<Reanalise> CadastrarReanaliseResultado(Reanalise reanalise)
    {
        var query = @"DELETE FROM Z24010 WHERE Z24_CODRES = @Z24_CODRES";

        await dbConnection.ExecuteAsync(query, new { Z24_CODRES = reanalise.Codigo });

        query = @"INSERT INTO Z24010
                        (Z24_FILIAL, Z24_CODRES, Z24_CODESP, Z24_VALESP, R_E_C_N_O_)
                    VALUES
                        (@Z24_FILIAL, @Z24_CODRES, @Z24_CODESP, @Z24_VALESP, (SELECT IDENT_CURRENT('Z24010')))";
        
        var parameters =
            reanalise.TiposEspecificacoes
                .Select(t =>
                {
                    var parameters = new
                    {
                        Z24_FILIAL = "0101",
                        Z24_CODRES = reanalise.ResultadoCodigo,
                        Z24_CODESP = t.Codigo,
                        Z24_VALESP = t.Valor
                    };

                    return parameters;
                }).ToList();


        if (reanalise.Abrasao is not null)
        {
            parameters.Add(new
            {
                Z24_FILIAL = "0101",
                Z24_CODRES = reanalise.ResultadoCodigo,
                Z24_CODESP = "000005",
                Z24_VALESP = reanalise.Abrasao.Abrasividade
            });

            await CadastrarAbrasaoReanalise(reanalise);
        }

        await dbConnection.ExecuteAsync(query, parameters);

        return reanalise;
    }
}