﻿using AutoMapper;
using CertificadoAnaliseQualidade.Domain.Models.Abstracts;

namespace CertificadoAnaliseQualidade.DbAdapter.Clients;

public class TipoEspecificacaoFactory
{
    public TipoEspecificacao Create(IMapper mapper, TipoEspecificacaoDto tipoEspecificacaoDto)
    {
        switch (tipoEspecificacaoDto.Z11_COD.Trim())
        {
            case "000002":
                return mapper.Map<DensidadeAparenteTipoEspecificacao>(tipoEspecificacaoDto);
            case "000001":
                return mapper.Map<DurezaTipoEspecificacao>(tipoEspecificacaoDto);
            case "000003":
                return mapper.Map<FluidezTipoEspecificacao>(tipoEspecificacaoDto);
            case "000004":
                return mapper.Map<ExpansaoTipoEspecificacao>(tipoEspecificacaoDto);
            case "000005":
                return mapper.Map<AbrasaoTipoEspecificacao>(tipoEspecificacaoDto);
            case "000006":
                return mapper.Map<DensidadeTipoEspecificacao>(tipoEspecificacaoDto);
            case "000007":
                return mapper.Map<UmidadeTipoEspecificacao>(tipoEspecificacaoDto);
            default:
                return default;
        }
    }

}
