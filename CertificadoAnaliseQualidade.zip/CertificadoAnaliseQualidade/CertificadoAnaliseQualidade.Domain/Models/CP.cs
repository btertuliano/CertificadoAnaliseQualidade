﻿namespace CertificadoAnaliseQualidade.Domain.Models;

public class CP
{
    /// <summary>
    /// Massa inicial do corpo de prova
    /// </summary>
    public decimal MI { get; set; }

    /// <summary>
    /// Massa final do corpo de prova
    /// </summary>
    public decimal MF { get; set; }

    /// <summary>
    /// Ordem do Corpo de prova
    /// </summary>
    public short Ordem { get; set; }

}
