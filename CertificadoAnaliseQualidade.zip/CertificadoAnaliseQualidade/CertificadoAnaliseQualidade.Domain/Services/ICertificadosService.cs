﻿using CertificadoAnaliseQualidade.Domain.Models;

namespace CertificadoAnaliseQualidade.Domain.Services;

public interface ICertificadosService
{
    /// <summary>
    /// Obtém certificado por lote
    /// </summary>
    /// <param name="lote">Lote de localização do produto</param>
    /// <returns>Dados do certificado</returns>
    Task<Certificado> ObterCertificadoPorLoteAsync(string lote);

    /// <summary>
    /// Obtém certificado pelo código
    /// </summary>
    /// <param name="codigo">Código do certificado</param>
    /// <returns>Dados do certificado</returns>
    Task<Certificado> ObterCertificadoAsync(int codigo);

    /// <summary>
    /// Cadastra um novo certificado
    /// </summary>
    /// <param name="certificado">Dados do certificado</param>
    /// <returns>Novo certificado</returns>
    Task<Certificado> CadastrarCertificadoAsync(Certificado certificado);

    /// <summary>
    /// Atualiza certificado
    /// </summary>
    /// <param name="certificado">Dados do certificado</param>
    Task AtualizarCertificadoAsync(Certificado certificado);

    /// <summary>
    /// Atualiza o pré-teste
    /// </summary>
    /// <param name="preTeste">Dados do pré-teste</param>
    Task AtualizarPreTesteAsync(PreTeste preTeste);

    /// <summary>
    /// Cadastra um novo item para o pré-teste
    /// </summary>
    /// <param name="itemPreTeste">Dados do item do pré-teste</param>
    Task<ItemPreTeste> CadastrarItemPreTeste(ItemPreTeste itemPreTeste);

    /// <summary>
    /// Cadastra uma nova alteração de fórmula
    /// </summary>
    /// <param name="alteracaoFormula">Dados da alteração de fórmula</param>
    Task<AlteracaoFormula> CadastrarAlteracaoFormulaAsync(AlteracaoFormula alteracaoFormula);

    /// <summary>
    /// Cadastra um novo resultado
    /// </summary>
    /// <param name="resultadoCertificado">Dados do resultado</param>
    /// <returns></returns>
    Task<ResultadoCertificado> CadastrarResultado(ResultadoCertificado resultadoCertificado);

    /// <summary>
    /// Cadastra uma nova reanálise
    /// </summary>
    /// <param name="reanalise">Dados da reanálise</param>
    Task<Reanalise> CadastrarReanaliseResultado(Reanalise reanalise);
}