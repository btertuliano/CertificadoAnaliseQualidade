﻿using CertificadoAnaliseQualidade.Domain.Models;

namespace CertificadoAnaliseQualidade.WebMvc.Models.Formulario;

public class ReanaliseViewModel
{
    public Reanalise Reanalise { get; private set; }

    public ReanaliseViewModel(Reanalise reanalise)
    {
        Reanalise = reanalise;
    }
}
