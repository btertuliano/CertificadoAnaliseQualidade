﻿using AutoMapper;
using CertificadoAnaliseQualidade.DbAdapter.Clients;
using CertificadoAnaliseQualidade.Domain.Models;
using CertificadoAnaliseQualidade.Domain.Models.Abstracts;

namespace CertificadoAnaliseQualidade.DbAdapter;

public class DdAdapterMapperProfile : Profile
{
    public DdAdapterMapperProfile()
    {
        CreateMap<ProdutoDto, Produto>()
            .ForMember(destination => destination.Codigo, options => options.MapFrom(source => source.B1_COD.Trim()))
            .ForMember(destination => destination.Nome, options => options.MapFrom(source => source.B1_DESC.Trim()))
            .ForMember(destination => destination.Lote, options => options.MapFrom(source => source.B8_LOTECTL.Trim()))
            .ForMember(destination => destination.DataFabricacao, options => options.MapFrom(source => FormatarData(source.B8_DFABRIC)))
            .ReverseMap();

        CreateMap<Certificado, CertificadoDto>()
            .ForMember(destination => destination.Z16_FILIAL, options => options.MapFrom(source => "0101"))
            .ForMember(destination => destination.Z16_CODSEQ, options => options.MapFrom(source => source.Codigo))
            .ForMember(destination => destination.Z16_LOTE, options => options.MapFrom(source => source.Produto.Lote))
            .ForMember(destination => destination.Z16_SITCER, options => options.MapFrom(source => (int)source.SituacaoCertificado))
            .ForMember(destination => destination.Z16_DTCAD, options => options.MapFrom(source => FormatarData(source.DataCadastro)))
            .ForMember(destination => destination.Z16_LOTREF, options => options.MapFrom(source => source.LoteReferencia))
            .ForMember(destination => destination.Z16_OBS, options => options.MapFrom(source => source.ObservacaoCertificado));

        CreateMap<CertificadoDto, Certificado>()
            .ForMember(destination => destination.Codigo, options => options.MapFrom(source => source.Z16_CODSEQ))
            .ForMember(destination => destination.DataCadastro, options => options.MapFrom(source => FormatarData(source.Z16_DTCAD)))
            .ForMember(destination => destination.SituacaoCertificado, options => options.MapFrom(source => source.Z16_SITCER))
            .ForMember(destination => destination.LoteReferencia, options => options.MapFrom(source => source.Z16_LOTREF))
            .ForMember(destination => destination.ObservacaoCertificado, options => options.MapFrom(source => source.Z16_OBS));

        CreateMap<AlteracaoFormulaDto, AlteracaoFormula>()
            .ForMember(destination => destination.Codigo, options => options.MapFrom(source => source.Z19_CODALT))
            .ForMember(destination => destination.CertificadoCodigo, options => options.MapFrom(source => source.Z19_CODSEQ))
            .ForMember(destination => destination.DataHora, options => options.MapFrom(source => FormatarData(source.Z19_DTALT)))
            .ForMember(destination => destination.Amostra, options => options.MapFrom(source => source.Z19_SUBLOT))
            .ForMember(destination => destination.Analista, options => options.MapFrom(source => source.Z19_ANALIS))
            .ForMember(destination => destination.MotivoAlteracao, options => options.MapFrom(source => source.Z19_MALT))
            .ForMember(destination => destination.DescricaoAlteracao, options => options.MapFrom(source => source.Z19_DESCAL));

        CreateMap<AlteracaoFormula, AlteracaoFormulaDto>()
            .ForMember(destination => destination.Z19_FILIAL, options => options.MapFrom(source => "0101"))
            .ForMember(destination => destination.Z19_CODALT, options => options.MapFrom(source => source.Codigo))
            .ForMember(destination => destination.Z19_CODSEQ, options => options.MapFrom(source => source.CertificadoCodigo))
            .ForMember(destination => destination.Z19_DTALT, options => options.MapFrom(source => FormatarData(source.DataHora)))
            .ForMember(destination => destination.Z19_SUBLOT, options => options.MapFrom(source => source.Amostra))
            .ForMember(destination => destination.Z19_ANALIS, options => options.MapFrom(source => source.Analista))
            .ForMember(destination => destination.Z19_MALT, options => options.MapFrom(source => source.MotivoAlteracao))
            .ForMember(destination => destination.Z19_DESCAL, options => options.MapFrom(source => source.DescricaoAlteracao));

        CreateMap<AnaliseVisualItemPreTesteDto, AnaliseVisualItemPreTeste>()
            .ForMember(destination => destination.Codigo, options => options.MapFrom(source => source.Z20_CODAV))
            .ForMember(destination => destination.ItemPreTesteCodigo, options => options.MapFrom(source => source.Z20_CODITM))
            .ForMember(destination => destination.Cor, options => options.MapFrom(source => source.Z20_COR))
            .ForMember(destination => destination.MaDispersaoSilica, options => options.MapFrom(source => source.Z20_MDS))
            .ForMember(destination => destination.Granulometria, options => options.MapFrom(source => source.Z20_GRANU))
            .ForMember(destination => destination.Plastificacao, options => options.MapFrom(source => source.Z20_PLAST))
            .ForMember(destination => destination.Olhinhos, options => options.MapFrom(source => source.Z20_OLHIN))
            .ForMember(destination => destination.FitaMonorosca, options => options.MapFrom(source => source.Z20_FITAMO))
            .ForMember(destination => destination.Gases, options => options.MapFrom(source => source.Z20_GASES))
            .ForMember(destination => destination.Analista, options => options.MapFrom(source => source.Z20_ANALIS))
            .ForMember(destination => destination.Observacao, options => options.MapFrom(source => source.Z20_OBS))
            .ReverseMap();

        CreateMap<AnaliseVisualResultadoDto, AnaliseVisualResultado>()
            .ForMember(destination => destination.Codigo, options => options.MapFrom(source => source.Z23_CODAVR))
            .ForMember(destination => destination.ResultadoCodigo, options => options.MapFrom(source => source.Z23_CODRES))
            .ForMember(destination => destination.Cor, options => options.MapFrom(source => source.Z23_COR))
            .ForMember(destination => destination.MaDispersaoSilica, options => options.MapFrom(source => source.Z23_MDS))
            .ForMember(destination => destination.Granulometria, options => options.MapFrom(source => source.Z23_GRANU))
            .ForMember(destination => destination.Plastificacao, options => options.MapFrom(source => source.Z23_PLAST))
            .ForMember(destination => destination.Olhinhos, options => options.MapFrom(source => source.Z23_OLHIN))
            .ForMember(destination => destination.FitaMonorosca, options => options.MapFrom(source => source.Z23_FITAMO))
            .ForMember(destination => destination.Gases, options => options.MapFrom(source => source.Z23_GASES))
            .ForMember(destination => destination.Analista, options => options.MapFrom(source => source.Z23_ANALIS))
            .ForMember(destination => destination.Observacao, options => options.MapFrom(source => source.Z23_OBS));

        CreateMap<AnaliseVisualResultado, AnaliseVisualResultadoDto > ()
            .ForMember(destination => destination.Z23_FILIAL, options => options.MapFrom(source => "0101"))
            .ForMember(destination => destination.Z23_CODAVR, options => options.MapFrom(source => source.Codigo))
            .ForMember(destination => destination.Z23_CODRES, options => options.MapFrom(source => source.ResultadoCodigo))
            .ForMember(destination => destination.Z23_COR, options => options.MapFrom(source => source.Cor))
            .ForMember(destination => destination.Z23_MDS, options => options.MapFrom(source => source.MaDispersaoSilica))
            .ForMember(destination => destination.Z23_GRANU, options => options.MapFrom(source => source.Granulometria))
            .ForMember(destination => destination.Z23_PLAST, options => options.MapFrom(source => source.Plastificacao))
            .ForMember(destination => destination.Z23_OLHIN, options => options.MapFrom(source => source.Olhinhos))
            .ForMember(destination => destination.Z23_FITAMO, options => options.MapFrom(source => source.FitaMonorosca))
            .ForMember(destination => destination.Z23_GASES, options => options.MapFrom(source => source.Gases))
            .ForMember(destination => destination.Z23_ANALIS, options => options.MapFrom(source => source.Analista))
            .ForMember(destination => destination.Z23_OBS, options => options.MapFrom(source => source.Observacao));

        CreateMap<PreTesteDto, PreTeste>()
            .ForMember(destination => destination.Codigo, options => options.MapFrom(source => source.Z17_CODPTE))
            .ForMember(destination => destination.ConferenciaCarga, options => options.MapFrom(source => source.Z17_CONFCA))
            .ForMember(destination => destination.AssinaturaConferenciaCarga, options => options.MapFrom(source => source.Z17_ACONCA))
            .ForMember(destination => destination.ConferenciaOleo, options => options.MapFrom(source => source.Z17_CONFOL))
            .ForMember(destination => destination.AssinaturaConferenciaOleo, options => options.MapFrom(source => source.Z17_ACONOL));

        CreateMap<PreTeste, PreTesteDto>()
            .ForMember(destination => destination.Z17_FILIAL, options => options.MapFrom(source => "0101"))
            .ForMember(destination => destination.Z17_CODPTE, options => options.MapFrom(source => source.Codigo.ToString()))
            .ForMember(destination => destination.Z17_CONFCA, options => options.MapFrom(source => source.ConferenciaCarga))
            .ForMember(destination => destination.Z17_ACONCA, options => options.MapFrom(source => source.AssinaturaConferenciaCarga))
            .ForMember(destination => destination.Z17_CONFOL, options => options.MapFrom(source => source.ConferenciaOleo))
            .ForMember(destination => destination.Z17_ACONOL, options => options.MapFrom(source => source.AssinaturaConferenciaOleo));

        CreateMap<ItemPreTesteDto, ItemPreTeste>()
            .ForMember(destination => destination.Codigo, options => options.MapFrom(source => source.Z22_CODITM))
            .ForMember(destination => destination.PreTesteCodigo, options => options.MapFrom(source => source.Z22_CODPTE))
            .ForMember(destination => destination.DataHoraInjecao, options => options.MapFrom(source => FormatarDataHora(source.Z22_DTHINJ)))
            .ForMember(destination => destination.HoraTeste, options => options.MapFrom(source => FormatarHora(source.Z22_HTESTE)))
            .ForMember(destination => destination.HoraRetorno, options => options.MapFrom(source => FormatarHora(source.Z22_HRET)))
            .ForMember(destination => destination.AssinaturaAnalista, options => options.MapFrom(source => source.Z22_AANALT))
            .ForMember(destination => destination.AssinaturaMonitorLider, options => options.MapFrom(source => source.Z22_AMOLI))
            .ForMember(destination => destination.Observacao, options => options.MapFrom(source => source.Z22_OBS));

        CreateMap<ItemPreTeste, ItemPreTesteDto>()
            .ForMember(destination => destination.Z22_FILIAL, options => options.MapFrom(source => "0101"))
            .ForMember(destination => destination.Z22_CODPTE, options => options.MapFrom(source => source.PreTesteCodigo))
            .ForMember(destination => destination.Z22_DTHINJ, options => options.MapFrom(source => FormatarDataHora(source.DataHoraInjecao)))
            .ForMember(destination => destination.Z22_HTESTE, options => options.MapFrom(source => FormatarHora(source.HoraTeste)))
            .ForMember(destination => destination.Z22_HRET, options => options.MapFrom(source => FormatarHora(source.HoraRetorno)))
            .ForMember(destination => destination.Z22_AANALT, options => options.MapFrom(source => source.AssinaturaAnalista))
            .ForMember(destination => destination.Z22_AMOLI, options => options.MapFrom(source => source.AssinaturaMonitorLider))
            .ForMember(destination => destination.Z22_OBS, options => options.MapFrom(source => source.Observacao));

        CreateMap<ResultadoDto, ResultadoCertificado>()
            .ForMember(destination => destination.CertificadoCodigo, options => options.MapFrom(source => source.Z18_CODSEQ))
            .ForMember(destination => destination.Codigo, options => options.MapFrom(source => source.Z18_CODRES))
            .ForMember(destination => destination.Amostra, options => options.MapFrom(source => source.Z18_CODAM))
            .ForMember(destination => destination.DataInjecao, options => options.MapFrom(source => FormatarDataHora(source.Z18_DTHINJ)))
            .ForMember(destination => destination.HoraAnaliseFinal, options => options.MapFrom(source => FormatarHora(source.Z18_HAFIN)))
            .ForMember(destination => destination.AnalistaFechamento, options => options.MapFrom(source => source.Z18_AFECH))
            .ForMember(destination => destination.Quantidade, options => options.MapFrom(source => source.Z18_QTD))
            .ForMember(destination => destination.AnalistaEtiquetas, options => options.MapFrom(source => source.Z18_AETQ));

        CreateMap<ResultadoCertificado, ResultadoDto>()
            .ForMember(destination => destination.Z18_FILIAL, options => options.MapFrom(source => "0101"))
            .ForMember(destination => destination.Z18_CODSEQ, options => options.MapFrom(source => source.CertificadoCodigo))
            .ForMember(destination => destination.Z18_CODAM, options => options.MapFrom(source => source.Amostra))
            .ForMember(destination => destination.Z18_DTHINJ, options => options.MapFrom(source => FormatarDataHora(source.DataInjecao)))
            .ForMember(destination => destination.Z18_HAFIN, options => options.MapFrom(source => FormatarHora(source.HoraAnaliseFinal)))
            .ForMember(destination => destination.Z18_AFECH, options => options.MapFrom(source => source.AnalistaFechamento))
            .ForMember(destination => destination.Z18_QTD, options => options.MapFrom(source => source.Quantidade))
            .ForMember(destination => destination.Z18_AETQ, options => options.MapFrom(source => source.AnalistaEtiquetas));

        CreateMapTipoEspecificacao();
    }

    private DateTime FormatarData(string data)
    {
        if (data is null) {
            data = "19000101";
        }
        var ano = int.Parse(data.Substring(0, 4));
        var mes = int.Parse(data.Substring(4, 2));
        var dia = int.Parse(data.Substring(6, 2));

        return new DateTime(ano, mes, dia);
    }

    private string FormatarData(DateTime data)
    {
        return data.ToString("yyyyMMdd");
    }

    private DateTime FormatarDataHora(string dataHora)
    {
        var data = FormatarData(dataHora);
        var hora = FormatarHora(dataHora.Split(' ').Last());

        return new DateTime(data.Year, data.Month, data.Day, hora.Hours, hora.Minutes, 0);
    }

    private string FormatarDataHora(DateTime dataHora)
    {
        return dataHora.ToString("yyyyMMdd HHmm");
    }

    private TimeSpan FormatarHora(string hora)
    {
        var hr = int.Parse(hora.Substring(0, 2));
        var mi = int.Parse(hora.Substring(2, 2));

        return new TimeSpan(hr, mi, 0);
    }

    private string FormatarHora(TimeSpan hora)
    {
        return hora.ToString("hh''mm");
    }

    private void CreateMapTipoEspecificacao()
    {
        CreateMap<TipoEspecificacaoDto, TipoEspecificacao>()
            .ForMember(destination => destination.Codigo, options => options.MapFrom(source => source.Z11_COD))
            .ForMember(destination => destination.Valor, options => options.MapFrom(source => source.Z12_VALOR))
            .ForMember(destination => destination.Descricao, options => options.MapFrom(source => source.Z11_DESC))
            .ForMember(destination => destination.Tolerancia, options => options.MapFrom(source => source.Z12_TOLER))
            .Include<TipoEspecificacaoDto, DurezaTipoEspecificacao>()
            .Include<TipoEspecificacaoDto, DensidadeAparenteTipoEspecificacao>()
            .Include<TipoEspecificacaoDto, FluidezTipoEspecificacao>()
            .Include<TipoEspecificacaoDto, ExpansaoTipoEspecificacao>()
            .Include<TipoEspecificacaoDto, AbrasaoTipoEspecificacao>()
            .Include<TipoEspecificacaoDto, DensidadeTipoEspecificacao>()
            .Include<TipoEspecificacaoDto, UmidadeTipoEspecificacao>();

        CreateMap<TipoEspecificacao, TipoEspecificacaoDto>()
            .ForMember(destination => destination.Z11_COD, options => options.MapFrom(source => source.Codigo))
            .ForMember(destination => destination.Z12_VALOR, options => options.MapFrom(source => source.Valor))
            .ForMember(destination => destination.Z11_DESC, options => options.MapFrom(source => source.Descricao))
            .ForMember(destination => destination.Z12_TOLER, options => options.MapFrom(source => source.Tolerancia))
            .Include<DurezaTipoEspecificacao, TipoEspecificacaoDto>()
            .Include<DensidadeAparenteTipoEspecificacao, TipoEspecificacaoDto>()
            .Include<FluidezTipoEspecificacao, TipoEspecificacaoDto>()
            .Include<ExpansaoTipoEspecificacao, TipoEspecificacaoDto>()
            .Include<AbrasaoTipoEspecificacao, TipoEspecificacaoDto>()
            .Include<DensidadeTipoEspecificacao, TipoEspecificacaoDto>()
            .Include<UmidadeTipoEspecificacao, TipoEspecificacaoDto>();

        CreateMap<TipoEspecificacaoDto, DurezaTipoEspecificacao>()
            .ForMember(destination => destination.Descricao, options => options.MapFrom(source => "Dureza"));

        CreateMap<TipoEspecificacaoDto, DensidadeAparenteTipoEspecificacao>()
            .ForMember(destination => destination.Descricao, options => options.MapFrom(source => "Densidade aparente"));

        CreateMap<TipoEspecificacaoDto, FluidezTipoEspecificacao>()
            .ForMember(destination => destination.Descricao, options => options.MapFrom(source => "Fluídez"));

        CreateMap<TipoEspecificacaoDto, ExpansaoTipoEspecificacao>()
            .ForMember(destination => destination.Descricao, options => options.MapFrom(source => "Expansão"));

        CreateMap<TipoEspecificacaoDto, AbrasaoTipoEspecificacao>()
            .ForMember(destination => destination.Descricao, options => options.MapFrom(source => "Abrasão"));

        CreateMap<TipoEspecificacaoDto, DensidadeTipoEspecificacao>()
            .ForMember(destination => destination.Descricao, options => options.MapFrom(source => "Densidade"));

        CreateMap<TipoEspecificacaoDto, UmidadeTipoEspecificacao>()
            .ForMember(destination => destination.Descricao, options => options.MapFrom(source => "Umidade"));


        CreateMap<DurezaTipoEspecificacao, TipoEspecificacaoDto>();
        CreateMap<DensidadeAparenteTipoEspecificacao, TipoEspecificacaoDto>();
        CreateMap<FluidezTipoEspecificacao, TipoEspecificacaoDto>();
        CreateMap<ExpansaoTipoEspecificacao, TipoEspecificacaoDto>();
        CreateMap<AbrasaoTipoEspecificacao, TipoEspecificacaoDto>();
        CreateMap<DensidadeTipoEspecificacao, TipoEspecificacaoDto>();
        CreateMap<UmidadeTipoEspecificacao, TipoEspecificacaoDto>();

    }
}
