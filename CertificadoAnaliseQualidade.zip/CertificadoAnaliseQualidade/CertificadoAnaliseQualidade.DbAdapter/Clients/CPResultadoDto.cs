﻿namespace CertificadoAnaliseQualidade.DbAdapter.Clients;

public class CPResultadoDto
{
    public string Z26_FILIAL { get; set; }
    public int Z26_CODRES { get; set; }
    public decimal Z26_MICP1 { get; set; }
    public decimal Z26_MICP2 { get; set; }
    public decimal Z26_MICP3 { get; set; }
    public decimal Z26_MFCP1 { get; set; }
    public decimal Z26_MFCP2 { get; set; }
    public decimal Z26_MFCP3 { get; set; }
}
