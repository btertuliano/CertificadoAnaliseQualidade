﻿using CertificadoAnaliseQualidade.Domain.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CertificadoAnaliseQualidade.WebMvc.Models.Formulario;

public class IndexViewModel
{
    public IEnumerable<SelectListItem> Produtos { get; set; }

    public IndexViewModel(IEnumerable<Produto> produtos)
    {
        Produtos = produtos
            .OrderBy(p => p.Codigo)
            .Select(p => new SelectListItem { Value = p.Lote, Text = $"{p.Lote} - {p.Codigo} ({p.Nome})" })
            .ToList();

    }
}
