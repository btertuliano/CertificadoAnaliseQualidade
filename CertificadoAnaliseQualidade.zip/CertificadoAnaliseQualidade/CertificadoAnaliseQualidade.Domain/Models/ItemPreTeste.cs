﻿using CertificadoAnaliseQualidade.Domain.Models.Abstracts;

namespace CertificadoAnaliseQualidade.Domain.Models;

public class ItemPreTeste
{
    /// <summary>
    /// Código do item do pré-teste
    /// </summary>
    public int Codigo { get; set; }

    /// <summary>
    /// Código do pré-teste
    /// </summary>
    public int PreTesteCodigo { get; set; }

    /// <summary>
    /// Data e hora da injeção
    /// </summary>
    public DateTime DataHoraInjecao { get; set; }

    /// <summary>
    /// Hora do pré-teste
    /// </summary>
    public TimeSpan HoraTeste { get; set; }

    /// <summary>
    /// Hora do retorno do pré-teste
    /// </summary>
    public TimeSpan HoraRetorno { get; set; }

    /// <summary>
    /// Assinatura do analista aprovando o pré-teste
    /// </summary>
    public string AssinaturaAnalista { get; set; }

    /// <summary>
    /// Assinatura do monitor/líder aprovando o pré-teste
    /// </summary>
    public string AssinaturaMonitorLider { get; set; }

    /// <summary>
    /// Observação do pré-teste
    /// </summary>
    public string Observacao { get; set; }

    /// <summary>
    /// Dados da análise visual
    /// </summary>
    public AnaliseVisualItemPreTeste AnaliseVisualItemPreTeste { get; set; }

    /// <summary>
    /// Lista de especificações do produto
    /// </summary>
    public IEnumerable<TipoEspecificacao> TiposEspecificacoes { get; set; }

    /// <summary>
    /// Dados da abrasão do item pré-teste
    /// </summary>
    public Abrasao Abrasao { get; set; }
}