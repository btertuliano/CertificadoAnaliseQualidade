﻿namespace CertificadoAnaliseQualidade.DbAdapter.Clients;

public class CPReanaliseDto
{
    public string Z28_FILIAL { get; set; }
    public int Z28_CODRES { get; set; }
    public decimal Z28_MICP1 { get; set; }
    public decimal Z28_MICP2 { get; set; }
    public decimal Z28_MICP3 { get; set; }
    public decimal Z28_MFCP1 { get; set; }
    public decimal Z28_MFCP2 { get; set; }
    public decimal Z28_MFCP3 { get; set; }
}
