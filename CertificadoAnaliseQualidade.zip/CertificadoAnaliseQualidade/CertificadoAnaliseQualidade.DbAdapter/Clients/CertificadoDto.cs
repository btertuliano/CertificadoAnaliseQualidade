﻿namespace CertificadoAnaliseQualidade.DbAdapter.Clients;

public class CertificadoDto
{
    public string Z16_FILIAL { get; set; }
    public int Z16_CODSEQ { get; set; }
    public string Z16_LOTE { get; set; }
    public int Z16_SITCER { get; set; }
    public string Z16_LOTREF { get; set; }
    public string Z16_OBS { get; set; }
    public long R_E_C_N_O_ { get; set; }
    public string Z16_DTCAD { get; set; }

    public ProdutoDto Produto { get; set; }
    public PreTesteDto PreTeste { get; set; }

}
