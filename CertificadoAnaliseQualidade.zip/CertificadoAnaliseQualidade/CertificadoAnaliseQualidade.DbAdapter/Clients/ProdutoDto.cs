﻿namespace CertificadoAnaliseQualidade.DbAdapter.Clients;

public class ProdutoDto
{
    public string B1_COD { get; set; }
    public string B1_DESC { get; set; }
    public string B8_LOTECTL { get; set; }
    public string B8_DFABRIC { get; set; }

    public TipoEspecificacaoDto TipoEspecificacao { get; set; }
}
