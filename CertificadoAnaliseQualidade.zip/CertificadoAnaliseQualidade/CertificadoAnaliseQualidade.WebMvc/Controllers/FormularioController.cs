﻿using CertificadoAnaliseQualidade.Domain.Models;
using CertificadoAnaliseQualidade.Domain.Services;
using CertificadoAnaliseQualidade.WebMvc.Models.Formulario;
using Microsoft.AspNetCore.Mvc;

namespace CertificadoAnaliseQualidade.WebMvc.Controllers;

public class FormularioController : Controller
{
    private readonly IProdutosService produtosService;
    private readonly ICertificadosService certificadosService;

    public FormularioController(IProdutosService produtosService, ICertificadosService certificadosService)
    {
        this.produtosService = produtosService
            ?? throw new ArgumentNullException(nameof(produtosService));

        this.certificadosService = certificadosService
            ?? throw new ArgumentNullException(nameof(certificadosService));
    }

    public async Task<IActionResult> Index()
    {
        var produtos = await produtosService.ObterProdutosAsync();
        var model = new IndexViewModel(produtos);

        return View(model);
    }

    public async Task<int> ObterCertificadoPorLote(string lote)
    {
        var certificado = await certificadosService.ObterCertificadoPorLoteAsync(lote);

        return certificado is null ? 0 : certificado.Codigo;
    }

    public async Task<int> Novo(string lote)
    {
        var certificado = new Certificado
        {
            Produto = new Produto { Lote = lote },
            SituacaoCertificado = SituacaoCertificado.Aberto,
            DataCadastro = DateTime.Now.Date
        };

        var novoCertificado = await certificadosService.CadastrarCertificadoAsync(certificado);

        return novoCertificado.Codigo;
    }

    [HttpPut]
    public async Task AtualizarCertificado(Certificado certificado)
    {
        await certificadosService.AtualizarCertificadoAsync(certificado);
    }

    public async Task<IActionResult> Cadastro(int id)
    {
        var certificado = await certificadosService.ObterCertificadoAsync(id);

        var produto = await produtosService.ObterProdutoAsync(certificado.Produto.Codigo, certificado.Produto.Lote);

        var cadastroViewModel = new CadastroViewModel(certificado, produto);

        return View(cadastroViewModel);
    }

    public async Task AtualizarPreTeste(PreTeste preTeste)
    {
        await certificadosService.AtualizarPreTesteAsync(preTeste);
    }

    public async Task<ItemPreTeste> CadastrarItemPreTeste(ItemPreTeste itemPreTeste)
    {
        return await certificadosService.CadastrarItemPreTeste(itemPreTeste);
    }

    public async Task<ResultadoCertificado> CadastrarResultado(ResultadoCertificado resultadoCertificado)
    {
        return await certificadosService.CadastrarResultado(resultadoCertificado);
    }

    public async Task<Reanalise> CadastrarReanaliseResultado(Reanalise reanalise)
    {
        return await certificadosService.CadastrarReanaliseResultado(reanalise);
    }

    public async Task<AlteracaoFormula> CadastrarAlteracaoFormula(AlteracaoFormula alteracaoFormula)
    {
        return await certificadosService.CadastrarAlteracaoFormulaAsync(alteracaoFormula);
    }

    [HttpPost]
    public IActionResult ItensPreTeste(ItemPreTeste itemPreTeste)
    {
        var model = new ItemPreTesteViewModel(itemPreTeste);

        return PartialView("_ItensPreTeste", model);
    }
    public IActionResult AlteracoesFormulas(AlteracaoFormula alteracaoFormula)
    {
        var model = new AlteracaoFormulaViewModel(alteracaoFormula);

        return PartialView("_AlteracoesFormulas", model);
    }

    [HttpPost]
    public IActionResult ResultadoCertificado(ResultadoCertificado resultadoCertificado)
    {
        var model = new ResultadoViewModel(resultadoCertificado);

        return PartialView("_Resultado", model);
    }

    public IActionResult AnaliseVisualPreTeste()
    {
        return PartialView("AnaliseVisualPreTeste");
    }

    public IActionResult AnaliseVisualResultado()
    {
        return PartialView("AnaliseVisualResultado");
    }

    public IActionResult AbrasaoResultado()
    {
        return PartialView("AbrasaoResultado");
    }

    public IActionResult AnaliseVisualPreTesteLeitura(AnaliseVisualItemPreTeste analiseVisualItemPreTeste)
    {
        var analiseVisualPreTesteLeituraViewModel = new AnaliseVisualPreTesteLeituraViewModel(analiseVisualItemPreTeste);

        return PartialView("_AnaliseVisualPreTesteLeitura", analiseVisualPreTesteLeituraViewModel);
    }

    public IActionResult AnaliseVisualResultadoLeitura(AnaliseVisualResultado analiseVisualResultado)
    {
        var analiseVisualResultadoLeituraViewModel = new AnaliseVisualResultadoLeituraViewModel(analiseVisualResultado);

        return PartialView("_AnaliseVisualResultadoLeitura", analiseVisualResultadoLeituraViewModel);
    }

    [HttpPost]
    public IActionResult AbrasaoItemPreTesteLeitura(Abrasao abrasao)
    {
        var abrasaoItemPreTesteLeituraViewModel = new AbrasaoItemPreTesteLeituraViewModel(abrasao);

        return PartialView("_AbrasaoItemPreTesteLeitura", abrasaoItemPreTesteLeituraViewModel);
    }

    [HttpPost]
    public IActionResult AbrasaoResultadoLeitura(Abrasao abrasao)
    {
        var abrasaoResultadoLeituraViewModel = new AbrasaoResultadoLeituraViewModel(abrasao);

        return PartialView("_AbrasaoResultadoLeitura", abrasaoResultadoLeituraViewModel);
    }

    public IActionResult ReanaliseResultado(Reanalise reanalise)
    {
        var reanaliseResultado = new ReanaliseViewModel(reanalise);

        return PartialView("_ReanaliseResultado", reanaliseResultado);
    }
}
