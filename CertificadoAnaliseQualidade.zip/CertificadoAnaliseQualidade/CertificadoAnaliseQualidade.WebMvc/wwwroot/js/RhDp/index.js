﻿$(document).ready(function () {

    $('#pretensaoSalarial').mask("#,##0.00", { reverse: true });
    $('#dataAdmissaoUltimoEmprego').mask('99/99/9999');
    $('#datademissaoUltimoEmprego').mask('99/99/9999');
    $('#dataAdmissaoPenultimoEmprego').mask('99/99/9999');
    $('#datademissaoPenultimoEmprego').mask('99/99/9999');
    $('#dataAdmissaoAntepenultimoEmprego').mask('99/99/9999');
    $('#datademissaoAntepenultimoEmprego').mask('99/99/9999');
    $('#periodoInicialFuncionarioLev').mask('99/99/9999');
    $('#periodofinalFuncionarioLev').mask('99/99/9999');
    $('#telefone').mask('(00) 00000-0000');
    $('#celular').mask('(00) 00000-0000');
    $('#telefoneRecado').mask('(00) 00000-0000');
    $("#dataNascimento").mask("99/99/9999");
    $("#dataCarteiraIdentidade").mask("99/99/9999");
    $("#dataVencimento").mask("99/99/9999");
    $("#cpf").mask("999.999.999-99");
    $("#cep").mask("99999-999");

    $('#email').blur(function () {
        var er = new RegExp(/^[A-Za-z0-9_\-\.]+@[A-Za-z0-9_\-\.]{2,}\.[A-Za-z0-9]{2,}(\.[A-Za-z0-9])?/);
        var email = $('#email').val();

        if (email == '' || !er.test(email)) {
            alert('erro' + email);
            $('#mensagemErroEmail').show();
            $('#mensagemErroEmail').text('Preencha o campo email corretamente');
            return false;
        } else {
            $('#mensagemErroEmail').hide();
        }
    });

    function limpa_formulário_cep() {
        // Limpa valores do formulário de cep.
        $("#cep").val("");
        $("#logradouro").val("");
        $("#numero").val("");
        $("#bairro").val("");
        $("#cidade").val("");
        $("#uf").val("");
    }

    function idade(mesNascimento, diaNascimento, anoNascimento, mesAtual, diaAtual, anoAtual) {
        var diferencaAnos = anoAtual - anoNascimento;

        //Verifica se no ano atual o dia do nascimento já passou, se não subtrai 1
        if (new Date(anoAtual, mesAtual, diaAtual) <
            new Date(anoAtual, mesNascimento, diaNascimento))
            diferencaAnos--;

        return diferencaAnos;
    }

    $("#dataNascimento").blur(function () {
        //Recebe a data de nascimento e separa em dia, mês e ano
        var nascimento = $("#dataNascimento").val();
        split = nascimento.split('/');
        var mesNascimento = split[1];
        var diaNascimento = split[0];
        var anoNascimento = split[2];

        //Busca a data atual e separa em dia, mês e ano
        var fullDate = new Date();
        var mesAtual = ((fullDate.getMonth().toString().length) == 1) ? '0' + (fullDate.getMonth() + 1) : (fullDate.getMonth() + 1);
        var diaAtual = ((fullDate.getDate().toString().length) == 1) ? '0' + (fullDate.getDate()) : (fullDate.getDate());
        var anoAtual = fullDate.getFullYear();

        if (nascimento) {
            $("#idade").val(idade(mesNascimento, diaNascimento, anoNascimento, mesAtual, diaAtual, anoAtual));
        }
    });

    //Quando o campo cep perde o foco.
    $("#cep").blur(function () {

        //Nova variável "cep" somente com dígitos.
        var cep = $(this).val().replace(/\D/g, '');

        //Verifica se campo cep possui valor informado.
        if (cep != "") {

            //Expressão regular para validar o CEP.
            var validacep = /^[0-9]{8}$/;

            //Valida o formato do CEP.
            if (validacep.test(cep)) {

                //Preenche os campos com "..." enquanto consulta webservice.
                $("#logradouro").val("...");
                $("#numero").val("...");
                $("#bairro").val("...");
                $("#cidade").val("...");
                $("#uf").val("...");

                //Consulta o webservice viacep.com.br/
                $.getJSON("https://viacep.com.br/ws/" + cep + "/json/?callback=?", function (dados) {

                    if (!("erro" in dados)) {
                        //Atualiza os campos com os valores da consulta.
                        $("#logradouro").val(dados.logradouro);
                        $("#numero").val("");
                        $("#numero").focus();
                        $("#bairro").val(dados.bairro);
                        $("#cidade").val(dados.localidade);
                        $("#uf").val(dados.uf);
                    } //end if.
                    else {
                        //CEP pesquisado não foi encontrado.
                        limpa_formulário_cep();
                        alert("CEP não encontrado.");
                        $("#cep").focus();
                    }
                });
            } //end if.
            else {
                //cep é inválido.
                limpa_formulário_cep();
                alert("Formato de CEP inválido.");
                $("#cep").focus();
            }
        } //end if.
        else {
            //cep sem valor, limpa formulário.
            limpa_formulário_cep();
            $("#cep").focus();
        }
    });

});