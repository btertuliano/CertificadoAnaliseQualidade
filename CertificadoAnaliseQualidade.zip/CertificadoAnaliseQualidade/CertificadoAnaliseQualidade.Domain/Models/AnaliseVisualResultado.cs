﻿namespace CertificadoAnaliseQualidade.Domain.Models;

public class AnaliseVisualResultado
{
    /// <summary>
    /// Código da análise visual resultado
    /// </summary>
    public int Codigo { get; set; }

    /// <summary>
    /// Código do certificado
    /// </summary>
    public int ResultadoCodigo { get; set; }

    /// <summary>
    /// Determina o tamanho e suas partículas
    /// </summary>
    public AnaliseVisualResultadoTipo Granulometria { get; set; }

    /// <summary>
    /// Plastificação da amostra
    /// </summary>
    public AnaliseVisualResultadoTipo Plastificacao { get; set; }

    /// <summary>
    /// Cor da amostra
    /// </summary>
    public AnaliseVisualResultadoTipo Cor { get; set; }

    /// <summary>
    /// Manchas brancas na formação da amostra
    /// </summary>
    public AnaliseVisualResultadoTipo MaDispersaoSilica { get; set; }

    /// <summary>
    /// Extrusora solta uma fita bem fina para teste
    /// </summary>
    public AnaliseVisualResultadoTipo FitaMonorosca { get; set; }

    /// <summary>
    /// Gases da amostra
    /// </summary>
    public AnaliseVisualResultadoTipo Gases { get; set; }

    /// <summary>
    /// Matéria prima não derrete de forma correta
    /// </summary>
    public AnaliseVisualResultadoTipo Olhinhos { get; set; }

    /// <summary>
    /// Analista que executou a análise visual
    /// </summary>
    public string Analista { get; set; }

    /// <summary>
    /// Observação da análise visual
    /// </summary>
    public string Observacao { get; set; }
}
public enum AnaliseVisualResultadoTipo
{
    Sim = 1,
    Nao = 0,
    Na = 2
}
