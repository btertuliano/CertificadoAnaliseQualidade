﻿namespace CertificadoAnaliseQualidade.Domain.Models;

public class AlteracaoFormula
{
    /// <summary>
    /// Código da alteração de fórmula
    /// </summary>
    public int Codigo { get; set; }

    /// <summary>
    /// Código do certificado
    /// </summary>
    public int CertificadoCodigo { get; set; }

    /// <summary>
    /// Data e hora que foi feita alteração na fórmula
    /// </summary>
    public DateTime DataHora { get; set; }

    /// <summary>
    /// Retorna a quantidade necessária para retirar uma amostra para teste
    /// </summary>
    public string Amostra { get; set; }

    /// <summary>
    /// Analisa que fez alteração da fórmula
    /// </summary>
    public string Analista { get; set; }

    /// <summary>
    /// Motivo da alteração da fórmula
    /// </summary>
    public string MotivoAlteracao { get; set; }

    /// <summary>
    /// Descrição da alteração da fórmula
    /// </summary>
    public string DescricaoAlteracao { get; set; }
}
