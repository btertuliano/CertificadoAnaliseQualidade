﻿using CertificadoAnaliseQualidade.Domain.Adapters;
using CertificadoAnaliseQualidade.Domain.Models;
using CertificadoAnaliseQualidade.Domain.Services;
using Microsoft.Extensions.Logging;

namespace CertificadoAnaliseQualidade.Application;

public class ProdutosService : IProdutosService
{
    private readonly IDbAdapter dbAdapter;
    private readonly ILogger logger;

    public ProdutosService(IDbAdapter dbAdapter, ILoggerFactory loggerFactory)
    {
        this.dbAdapter = dbAdapter
            ?? throw new ArgumentNullException(nameof(dbAdapter));

        logger = loggerFactory?.CreateLogger<ProdutosService>()
            ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<Produto> ObterProdutoAsync(string codigo, string lote)
    {
        logger.LogInformation($"Realizando chamada ao método {nameof(ObterProdutoAsync)}");

        var produto = await dbAdapter.ObterProdutoAsync(codigo, lote);

        logger.LogInformation($"Chamada ao método {nameof(ObterProdutoAsync)} realizada");

        return produto;
    }

    public async Task<IEnumerable<Produto>> ObterProdutosAsync()
    {
        logger.LogInformation("Realizando chamada ao método {ObterProdutosAsync}", nameof(ObterProdutosAsync));

        var produtos = await dbAdapter.ObterProdutosAsync();

        logger.LogInformation("Chamada ao método {ObterProdutosAsync} realizada", nameof(ObterProdutosAsync));

        return produtos;
    }
}
