﻿namespace CertificadoAnaliseQualidade.Domain.Models.Abstracts;

public class TipoEspecificacao
{
    /// <summary>
    /// Códgio da especificação
    /// </summary>
    public string Codigo { get; set; }

    /// <summary>
    /// Valor do tipo de especificação
    /// </summary>
    public decimal Valor { get; set; }

    /// <summary>
    /// Tolerância do tipo de especificação
    /// </summary>
    public decimal Tolerancia { get; set; }

    /// <summary>
    /// Descrição do tipo de especificação
    /// </summary>
    public string Descricao { get; set; }

}

/// <summary>
/// Média Densidade Resultado
/// </summary>
public class DensidadeTipoEspecificacao : TipoEspecificacao { }
/// <summary>
/// Média dos lançamentos de densidade aparente do resultado
/// </summary>
public class DensidadeAparenteTipoEspecificacao : TipoEspecificacao { }
/// <summary>
/// Média dureza final resultado
/// </summary>
public class DurezaTipoEspecificacao : TipoEspecificacao { }
/// <summary>
/// Média Índice de Fluidez (g/10 min) do resultado
/// </summary>
public class FluidezTipoEspecificacao : TipoEspecificacao { }
/// <summary>
/// Média dos lançamentos expansão do resultado
/// </summary>
public class ExpansaoTipoEspecificacao : TipoEspecificacao { }
/// <summary>
/// Média da média do calculo abrasão
/// </summary>
public class AbrasaoTipoEspecificacao : TipoEspecificacao { }
/// <summary>
/// Entrada manual
/// </summary>
public class UmidadeTipoEspecificacao : TipoEspecificacao { }
