﻿using CertificadoAnaliseQualidade.Domain.Models;

namespace CertificadoAnaliseQualidade.WebMvc.Models.Formulario;

public class AlteracaoFormulaViewModel
{
    public AlteracaoFormula AlteracaoFormula { get; private set; }

    public AlteracaoFormulaViewModel(AlteracaoFormula alteracaoFormula)
    {
        AlteracaoFormula = alteracaoFormula;
    }
}
