﻿namespace CertificadoAnaliseQualidade.DbAdapter.Clients;

public class PreTesteDto
{
    public string Z17_FILIAL { get; set; }
    public int Z17_CODPTE { get; set; }
    public int Z17_CODSEQ { get; set; }
    public float Z17_CONFCA { get; set; }
    public string Z17_ACONCA { get; set; }
    public float Z17_CONFOL { get; set; }
    public string Z17_ACONOL { get; set; }
    public IEnumerable<ItemPreTesteDto> Itens { get; set; }
}

public class ItemPreTesteDto
{
    public string Z22_FILIAL { get; set; }
    public int Z22_CODITM { get; set; }
    public int Z22_CODPTE { get; set; }
    public string Z22_DTHINJ { get; set; }
    public string Z22_HTESTE { get; set; }
    public string Z22_HRET { get; set; }
    public string Z22_AANALT { get; set; }
    public string Z22_AMOLI { get; set; }
    public string Z22_OBS { get; set; }
    public AnaliseVisualItemPreTesteDto AnaliseVisualItemPreTeste { get; set; }
}

public class AnaliseVisualItemPreTesteDto
{
    public string Z20_FILIAL { get; set; }
    public int Z20_CODAV { get; set; }
    public int Z20_CODITM { get; set; }
    public int Z20_COR { get; set; }
    public int Z20_MDS { get; set; }
    public int Z20_GRANU { get; set; }
    public int Z20_PLAST { get; set; }
    public int Z20_OLHIN { get; set; }
    public int Z20_FITAMO { get; set; }
    public int Z20_GASES { get; set; }
    public string Z20_ANALIS { get; set; }
    public string Z20_OBS { get; set; }
}

public class AbrasaoItemPreTesteDto
{
    public string Z27_FILIAL { get; set; }
    public int Z27_CODAIP { get; set; }
    public int Z27_CODITM { get; set; }
    public decimal Z27_MICP1 { get; set; }
    public decimal Z27_MICP2 { get; set; }
    public decimal Z27_MICP3 { get; set; }
    public decimal Z27_MFCP1 { get; set; }
    public decimal Z27_MFCP2 { get; set; }
    public decimal Z27_MFCP3 { get; set; }
    public decimal Z21_VALESP { get; set; }
}